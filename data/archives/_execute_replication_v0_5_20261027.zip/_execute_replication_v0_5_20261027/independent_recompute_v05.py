"""Independent arithmetic validation of the completed v0.4 replication.

This script does not import the frozen launcher, campaign runner, geometry
engines, oracle, or analyzer.  It recomputes the prespecified statistics from
the serialized campaign table and validates the frozen analyzer outputs.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import statistics
import time
from collections import defaultdict
from pathlib import Path

from scipy.stats import t as student_t


WORKSPACE = Path(__file__).resolve().parent.parent
PREP = WORKSPACE / "_prepare_replication_v0_4_20261027"
CAMPAIGN = PREP / "campaign_v04"
ANALYSIS = PREP / "analysis_v04"
OUT_DIR = WORKSPACE / "_execute_replication_v0_5_20261027" / "validation"
OUT_PATH = OUT_DIR / "independent_recompute_v05.json"

BETAS = ("0.30", "0.31", "0.32", "1/3", "0.34", "0.35", "0.36")
RADII = (256, 512)
ORIENTATIONS = ("theta0", "atan_1_8", "pi_over_4")
Q_VALUES = (0.95, 0.90, 0.85)
EXPECTED_QH = (0, 8, 16, 24, 32, 40, 48, 56)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


MAX_COMPARISON_DELTA = 0.0


def compare_float(actual: float, expected: float, label: str) -> None:
    global MAX_COMPARISON_DELTA
    actual = float(actual)
    expected = float(expected)
    delta = abs(actual - expected)
    MAX_COMPARISON_DELTA = max(MAX_COMPARISON_DELTA, delta)
    if not math.isclose(actual, expected, rel_tol=5e-13, abs_tol=5e-20):
        raise AssertionError(f"{label}: {actual!r} != {expected!r} (delta={delta!r})")


def summary(values):
    values = list(map(float, values))
    require(len(values) >= 2, "summary requires at least two values")
    return {
        "n": len(values),
        "mean": statistics.fmean(values),
        "sd_ddof1": statistics.stdev(values),
        "min": min(values),
        "max": max(values),
    }


def compare_summary(actual, expected, label: str) -> None:
    require(int(actual["n"]) == int(expected["n"]), f"{label}.n")
    for field in ("mean", "sd_ddof1", "min", "max"):
        compare_float(actual[field], expected[field], f"{label}.{field}")


def main() -> None:
    started = time.perf_counter()
    campaign_path = CAMPAIGN / "campaign_cells_v04.csv"
    contrast_path = ANALYSIS / "cell_contrasts_v04.csv"
    results_path = ANALYSIS / "analysis_results_v04.json"
    analysis_manifest_path = ANALYSIS / "analysis_manifest_v04.json"
    completion_path = CAMPAIGN / "campaign_complete_manifest_v04.json"
    translation_path = PREP / "translations_v04.json"

    completion = read_json(completion_path)
    translations = read_json(translation_path)
    results = read_json(results_path)
    analysis_manifest = read_json(analysis_manifest_path)
    require(completion["status"] == "COMPLETE_64_ROWS", "campaign status")
    require(completion["row_count"] == 64, "campaign row count")
    require(completion["expanded_cell_count"] == 8064, "campaign expanded cells")
    require(completion["geometry_divergence_count"] == 0, "geometry divergence")
    require(completion["second_engine_row_indices_zero_based"] == list(EXPECTED_QH), "QuickHull plan")
    require(completion["cells_sha256"] == sha256(campaign_path), "campaign CSV hash")

    translation_records = translations["translations"]
    require(len(translation_records) == 64, "translation count")
    identities = {
        int(record["row_index"]): (
            int(record["tx"]), int(record["ty"]), int(record["denominator"]), record["provenance"]
        )
        for record in translation_records
    }
    require(sorted(identities) == list(range(64)), "translation row order")
    require(len(set(identities.values())) == 64, "translation identities are not unique")

    expected_header = [
        "row_index", "tx", "ty", "denominator", "provenance", "R", "orientation",
        "q_historical", "q_absolute", "beta_label", "beta", "peel_a3_shape_real",
        "peel_a3_shape_imag", "reference_a3_shape_real", "reference_a3_shape_imag",
        "epsilon_interp_a3", "epsilon_ref_a3_qualification_grid_max",
    ]
    grouped = defaultdict(dict)
    campaign_row_count = 0
    with campaign_path.open("r", encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream)
        require(reader.fieldnames == expected_header, "campaign CSV header")
        for record in reader:
            campaign_row_count += 1
            row_index = int(record["row_index"])
            identity = (
                int(record["tx"]), int(record["ty"]), int(record["denominator"]), record["provenance"]
            )
            require(identity == identities[row_index], f"identity mismatch at row {row_index}")
            key = (
                row_index, int(record["R"]), record["orientation"], float(record["q_historical"])
            )
            label = record["beta_label"]
            require(label in BETAS, f"unexpected beta {label}")
            require(label not in grouped[key], f"duplicate beta in {key}")
            grouped[key][label] = record
    require(campaign_row_count == 8064, "campaign CSV row count")
    require(len(grouped) == 1152, "campaign group count")

    contrast_header = [
        "row_index", "tx", "ty", "denominator", "provenance", "R", "orientation",
        "q_historical", "q_absolute", "epsilon_interp_a3", "epsilon_ref_1_over_3",
        "epsilon_ref_0_32", "loss_1_over_3", "loss_0_32", "d_raw",
        "B_common_interpolation", "B_reference_1_over_3", "B_reference_0_32",
        "B_mixed", "B_empirical", "d_minus_B",
    ]
    reported_contrasts = {}
    with contrast_path.open("r", encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream)
        require(reader.fieldnames == contrast_header, "contrast CSV header")
        for record in reader:
            key = (
                int(record["row_index"]), int(record["R"]), record["orientation"],
                float(record["q_historical"]),
            )
            require(key not in reported_contrasts, f"duplicate reported contrast {key}")
            reported_contrasts[key] = record
    require(len(reported_contrasts) == 1152, "reported contrast count")
    require(set(reported_contrasts) == set(grouped), "contrast/campaign key mismatch")

    cells = {}
    for key, beta_rows in grouped.items():
        require(tuple(beta_rows) == BETAS, f"beta order or completeness changed in {key}")
        row_index, radius, orientation, q_value = key
        require(radius in RADII and orientation in ORIENTATIONS and q_value in Q_VALUES, f"grid {key}")
        first = beta_rows[BETAS[0]]
        p = complex(float(first["peel_a3_shape_real"]), float(first["peel_a3_shape_imag"]))
        q_absolute = float(first["q_absolute"])
        epsilon_interp = float(first["epsilon_interp_a3"])
        losses = {}
        references = {}
        eps_refs = {}
        for label in BETAS:
            record = beta_rows[label]
            require(
                complex(float(record["peel_a3_shape_real"]), float(record["peel_a3_shape_imag"])) == p,
                f"target differs across beta in {key}",
            )
            compare_float(record["q_absolute"], q_absolute, f"q_absolute identity {key} {label}")
            compare_float(record["epsilon_interp_a3"], epsilon_interp, f"epsilon_interp identity {key} {label}")
            reference = complex(
                float(record["reference_a3_shape_real"]), float(record["reference_a3_shape_imag"])
            )
            references[label] = reference
            eps_refs[label] = float(record["epsilon_ref_a3_qualification_grid_max"])
            losses[label] = abs(p - reference) ** 2

        r13 = references["1/3"]
        r032 = references["0.32"]
        e13 = eps_refs["1/3"]
        e032 = eps_refs["0.32"]
        loss13 = losses["1/3"]
        loss032 = losses["0.32"]
        d_raw = loss13 - loss032
        b_common = 2.0 * epsilon_interp * abs(r13 - r032)
        b_ref13 = 2.0 * abs(p - r13) * e13 + e13**2
        b_ref032 = 2.0 * abs(p - r032) * e032 + e032**2
        b_mixed = 2.0 * epsilon_interp * (e13 + e032)
        b_empirical = b_common + b_ref13 + b_ref032 + b_mixed
        d_minus_b = d_raw - b_empirical

        reported = reported_contrasts[key]
        require(
            (int(reported["tx"]), int(reported["ty"]), int(reported["denominator"]), reported["provenance"])
            == identities[row_index],
            f"reported identity {key}",
        )
        for field, value in (
            ("q_absolute", q_absolute), ("epsilon_interp_a3", epsilon_interp),
            ("epsilon_ref_1_over_3", e13), ("epsilon_ref_0_32", e032),
            ("loss_1_over_3", loss13), ("loss_0_32", loss032), ("d_raw", d_raw),
            ("B_common_interpolation", b_common), ("B_reference_1_over_3", b_ref13),
            ("B_reference_0_32", b_ref032), ("B_mixed", b_mixed),
            ("B_empirical", b_empirical), ("d_minus_B", d_minus_b),
        ):
            compare_float(value, reported[field], f"contrast {key}.{field}")
        cells[key] = {"d_raw": d_raw, "d_minus_b": d_minus_b, "losses": losses}

    row_w = {}
    for row_index in range(64):
        values = [
            cells[(row_index, 512, orientation, q_value)]["d_minus_b"]
            for orientation in ORIENTATIONS for q_value in Q_VALUES
        ]
        row_w[row_index] = statistics.fmean(values)
    w_values = [row_w[index] for index in range(64)]
    mean_w = statistics.fmean(w_values)
    sd_w = statistics.stdev(w_values)
    t63 = float(student_t.ppf(0.975, 63))
    lcb = mean_w - t63 * sd_w / math.sqrt(64)
    primary = results["primary"]
    require(primary["n_independent_translation_rows"] == 64, "primary n")
    compare_float(mean_w, primary["mean_W"], "primary mean W")
    compare_float(sd_w, primary["sd_W_ddof1"], "primary sd W")
    compare_float(t63, primary["student_t_quantile_0_975_df63"], "primary t63")
    compare_float(lcb, primary["lower_confidence_bound_nominal"], "primary LCB")
    expected_status = "FINITE_R512_PREFERENCE_0_32" if lcb > 0 else "NON_DISCRIMINE"
    require(results["status"] == expected_status, "primary decision status")
    reported_w = {int(item["row_index"]): item for item in primary["row_scores_with_exact_identity"]}
    require(set(reported_w) == set(range(64)), "reported W rows")
    for row_index in range(64):
        item = reported_w[row_index]
        require(
            (item["tx"], item["ty"], item["denominator"], item["provenance"]) == identities[row_index],
            f"reported W identity {row_index}",
        )
        compare_float(row_w[row_index], item["W"], f"W row {row_index}")

    loo_means, loo_lcbs = [], []
    reported_loo = {int(item["omitted_row_index"]): item for item in results["leave_one_translation_out"]["rows"]}
    require(set(reported_loo) == set(range(64)), "reported LOO rows")
    t62 = float(student_t.ppf(0.975, 62))
    for omitted in range(64):
        values = [row_w[index] for index in range(64) if index != omitted]
        loo_mean = statistics.fmean(values)
        loo_lcb = loo_mean - t62 * statistics.stdev(values) / math.sqrt(63)
        loo_means.append(loo_mean)
        loo_lcbs.append(loo_lcb)
        compare_float(loo_mean, reported_loo[omitted]["mean_W"], f"LOO mean {omitted}")
        compare_float(loo_lcb, reported_loo[omitted]["lcb"], f"LOO LCB {omitted}")
    loo = results["leave_one_translation_out"]
    compare_float(min(loo_means), loo["minimum_mean_W"], "LOO minimum mean")
    compare_float(max(loo_means), loo["maximum_mean_W"], "LOO maximum mean")
    compare_float(min(loo_lcbs), loo["minimum_lcb"], "LOO minimum LCB")
    compare_float(max(loo_lcbs), loo["maximum_lcb"], "LOO maximum LCB")
    require(sum(value > 0 for value in loo_lcbs) == loo["positive_count_of_64"], "LOO positive count")

    secondary = results["predeclared_secondary"]
    paired_scale = []
    for row_index in range(64):
        d512 = statistics.fmean(
            cells[(row_index, 512, orientation, q_value)]["d_raw"]
            for orientation in ORIENTATIONS for q_value in Q_VALUES
        )
        d256 = statistics.fmean(
            cells[(row_index, 256, orientation, q_value)]["d_raw"]
            for orientation in ORIENTATIONS for q_value in Q_VALUES
        )
        paired_scale.append(d512 - d256)
    compare_summary(summary(paired_scale), secondary["raw_paired_D512_minus_D256_by_translation"], "D512-D256")

    for orientation in ORIENTATIONS:
        values = [
            statistics.fmean(cells[(row_index, 512, orientation, q_value)]["d_raw"] for q_value in Q_VALUES)
            for row_index in range(64)
        ]
        compare_summary(summary(values), secondary["raw_D_at_R512_by_orientation"][orientation], f"angle {orientation}")
    for q_value, label in zip(Q_VALUES, ("0.95", "0.90", "0.85")):
        values = [
            statistics.fmean(cells[(row_index, 512, orientation, q_value)]["d_raw"] for orientation in ORIENTATIONS)
            for row_index in range(64)
        ]
        compare_summary(summary(values), secondary["raw_D_at_R512_by_q"][label], f"q {label}")
    for radius in RADII:
        values = [cells[(row_index, radius, "pi_over_4", 0.95)]["d_raw"] for row_index in range(64)]
        compare_summary(summary(values), secondary["raw_D_pi_over_4_q_0_95_by_R"][str(radius)], f"pi/4 q=.95 R{radius}")

    reported_losses = {
        (int(item["R"]), item["orientation"], float(item["q_historical"]), item["beta_label"]): item
        for item in secondary["all_seven_beta_losses"]
    }
    require(len(reported_losses) == 126, "reported seven-beta loss count")
    loss_overall = defaultdict(list)
    for radius in RADII:
        for orientation in ORIENTATIONS:
            for q_value in Q_VALUES:
                for beta in BETAS:
                    values = [cells[(row_index, radius, orientation, q_value)]["losses"][beta] for row_index in range(64)]
                    compare_summary(
                        summary(values), reported_losses[(radius, orientation, q_value, beta)],
                        f"loss R{radius} {orientation} q{q_value} beta{beta}",
                    )
                    loss_overall[(radius, beta)].extend(values)
    require(secondary["cannot_rescue_negative_primary"] is True, "secondary rescue flag")

    quickhull = []
    for row_index in EXPECTED_QH:
        path = CAMPAIGN / "rows" / f"row_{row_index:02d}_quickhull_check.json"
        payload = read_json(path)
        require(payload["status"] == "PASS_COMPLETE_LAYER_BY_LAYER_SECOND_ENGINE", f"QH status {row_index}")
        for field in (
            "exact_layer_indices", "exact_remaining_and_vertex_counts", "exact_vertex_sets",
            "exact_target_brackets", "cumulative_layer_record_sha256_equal",
        ):
            require(payload[field] is True, f"QH {row_index} {field}")
        require(payload["minimum_exact_adjacent_containment_cross"] >= 0, f"QH containment {row_index}")
        require(payload["maximum_perimeter_relative_difference"] <= 1e-12, f"QH perimeter {row_index}")
        require(payload["maximum_weight_absolute_difference"] <= 1e-12, f"QH weight {row_index}")
        require(max(payload["maximum_coefficient_absolute_differences"].values()) <= 1e-12, f"QH coeff {row_index}")
        require(payload["maximum_c0_target_residual"] <= 5e-14, f"QH c0 {row_index}")
        require(
            payload["cumulative_layer_record_sha256_primary"]
            == payload["cumulative_layer_record_sha256_secondary"],
            f"QH digest {row_index}",
        )
        quickhull.append({"row_index": row_index, "layers_compared": payload["layers_compared"], "sha256": sha256(path)})

    require(analysis_manifest["status"] == "ANALYZED_COMPLETE_64_ROWS", "analysis manifest status")
    require(analysis_manifest["result"]["sha256"] == sha256(results_path), "analysis result hash")
    require(analysis_manifest["cell_contrasts"]["sha256"] == sha256(contrast_path), "contrast hash")
    require(
        analysis_manifest["source_sha256"] == sha256(PREP / "analysis" / "analyze_replication_v04.py"),
        "analyzer source hash",
    )

    overall_loss_table = []
    for radius in RADII:
        for beta in BETAS:
            values = loss_overall[(radius, beta)]
            require(len(values) == 64 * 9, f"overall loss count R{radius} beta{beta}")
            overall_loss_table.append({"R": radius, "beta_label": beta, "mean_over_64x9": statistics.fmean(values)})

    result = {
        "status": "INDEPENDENT_RECOMPUTE_PASS",
        "method": "standard-library arithmetic plus scipy Student quantile; no frozen code imported",
        "campaign_rows": campaign_row_count,
        "contrast_groups": len(cells),
        "primary": {
            "n": 64,
            "mean_W": mean_w,
            "sd_W_ddof1": sd_w,
            "student_t_0_975_df63": t63,
            "lower_confidence_bound_nominal": lcb,
            "decision": expected_status,
        },
        "leave_one_out": {
            "minimum_mean_W": min(loo_means), "maximum_mean_W": max(loo_means),
            "minimum_lcb": min(loo_lcbs), "maximum_lcb": max(loo_lcbs),
            "positive_count_of_64": sum(value > 0 for value in loo_lcbs),
        },
        "seven_beta_mean_losses": overall_loss_table,
        "quickhull": quickhull,
        "maximum_absolute_numeric_delta_vs_frozen_outputs": MAX_COMPARISON_DELTA,
        "input_sha256": {
            "campaign_cells": sha256(campaign_path),
            "cell_contrasts": sha256(contrast_path),
            "analysis_results": sha256(results_path),
            "translations": sha256(translation_path),
            "campaign_completion": sha256(completion_path),
        },
        "script_sha256": sha256(Path(__file__).resolve()),
        "elapsed_wall_seconds": time.perf_counter() - started,
    }
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    require(not OUT_PATH.exists(), "independent validation output already exists")
    OUT_PATH.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
