"""Build the bounded execution manifest for the single v0.5 replication."""

from __future__ import annotations

import hashlib
import json
import platform
import re
import statistics
import sys
from datetime import datetime, timezone
from importlib import metadata
from pathlib import Path


WORKSPACE = Path(__file__).resolve().parent.parent
PREP = WORKSPACE / "_prepare_replication_v0_4_20261027"
EXECUTION = WORKSPACE / "_execute_replication_v0_5_20261027"
OUTPUT = EXECUTION / "execution_manifest_v05.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def record(path: Path) -> dict:
    return {"path": str(path.resolve()), "bytes": path.stat().st_size, "sha256": sha256(path)}


def tree_bytes(path: Path) -> int:
    return sum(item.stat().st_size for item in path.rglob("*") if item.is_file())


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    if OUTPUT.exists():
        raise FileExistsError(f"refusing to overwrite {OUTPUT}")

    frozen_path = PREP / "frozen_manifest_v04.json"
    state_path = PREP / "launcher_state_v04.json"
    translations_path = PREP / "translations_v04.json"
    seed_input_path = EXECUTION / "control" / "seed_input_v05.txt"
    seed_stored_path = PREP / "master_seed_v04.txt"
    completion_path = PREP / "campaign_v04" / "campaign_complete_manifest_v04.json"
    costs_path = PREP / "campaign_v04" / "campaign_costs_v04.json"
    analysis_results_path = PREP / "analysis_v04" / "analysis_results_v04.json"
    analysis_manifest_path = PREP / "analysis_v04" / "analysis_manifest_v04.json"
    independent_path = EXECUTION / "validation" / "independent_recompute_v05.json"

    frozen = read_json(frozen_path)
    state = read_json(state_path)
    translations = read_json(translations_path)
    completion = read_json(completion_path)
    costs = read_json(costs_path)
    analysis = read_json(analysis_results_path)
    independent = read_json(independent_path)
    seed = seed_input_path.read_text(encoding="ascii")
    seed_stored = seed_stored_path.read_text(encoding="ascii").strip()

    if re.fullmatch(r"[0-9a-f]{64}", seed) is None or seed_stored != seed:
        raise AssertionError("seed copies differ or are invalid")
    if state.get("last_completed_action") != "ANALYZE" or state.get("next_action") != "COMPLETE":
        raise AssertionError("launcher state is not complete")
    if completion.get("status") != "COMPLETE_64_ROWS" or completion.get("row_count") != 64:
        raise AssertionError("campaign is incomplete")
    if analysis.get("status") != "FINITE_R512_PREFERENCE_0_32":
        raise AssertionError("unexpected analysis status")
    if independent.get("status") != "INDEPENDENT_RECOMPUTE_PASS":
        raise AssertionError("independent recompute did not pass")
    if len(translations.get("translations", [])) != 64:
        raise AssertionError("translation manifest count")

    main_rows = costs["rows"]
    main_wall = [float(item["main_wall_seconds"]) for item in main_rows]
    main_cpu = [float(item["main_cpu_seconds"]) for item in main_rows]
    second_rows = [item for item in main_rows if item["second_wall_seconds"] is not None]
    second_wall = [float(item["second_wall_seconds"]) for item in second_rows]
    second_cpu = [float(item["second_cpu_seconds"]) for item in second_rows]

    artifacts = {
        "launch_advice_zip": record(WORKSPACE / "DYN-Avis_Lancement_et_Controles_v0_5.zip"),
        "frozen_manifest": record(frozen_path),
        "launcher_state_complete": record(state_path),
        "seed_input": record(seed_input_path),
        "seed_stored_by_draw": record(seed_stored_path),
        "authorization_draw": record(EXECUTION / "control" / "authorization_draw_v05.json"),
        "authorization_run": record(EXECUTION / "control" / "authorization_run_v05.json"),
        "translations": record(translations_path),
        "campaign_completion": record(completion_path),
        "campaign_cells": record(PREP / "campaign_v04" / "campaign_cells_v04.csv"),
        "campaign_costs": record(costs_path),
        "campaign_reference_json": record(PREP / "campaign_v04" / "campaign_reference_v04.json"),
        "campaign_reference_npz": record(PREP / "campaign_v04" / "campaign_reference_v04.npz"),
        "oracle_q_input": record(PREP / "campaign_v04" / "oracle_q_input_v04.json"),
        "analysis_results": record(analysis_results_path),
        "analysis_cell_contrasts": record(PREP / "analysis_v04" / "cell_contrasts_v04.csv"),
        "analysis_manifest": record(analysis_manifest_path),
        "independent_recompute_script": record(EXECUTION / "independent_recompute_v05.py"),
        "independent_recompute_result": record(independent_path),
        "control_creator_script": record(WORKSPACE / "_create_replication_controls_v05.py"),
        "control_creation_receipt": record(EXECUTION / "control" / "control_creation_receipt_v05.json"),
        "manifest_builder_script": record(Path(__file__).resolve()),
    }

    result = {
        "status": "SINGLE_PROSPECTIVE_REPLICATION_COMPLETE_NO_PUBLICATION",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "state": {"last_completed_action": "ANALYZE", "next_action": "COMPLETE"},
        "frozen_manifest_sha256": sha256(frozen_path),
        "frozen_environment": frozen["environment"],
        "observed_environment": {
            "python": platform.python_version(),
            "python_executable": sys.executable,
            "packages": {
                name: metadata.version(name)
                for name in ("numpy", "scipy", "mpmath", "threadpoolctl", "psutil")
            },
        },
        "randomization": {
            "master_seed_hex": seed,
            "master_seed_character_count": len(seed),
            "generator": translations["generator"],
            "candidate_calls": translations["candidate_calls"],
            "historical_blacklist_unique_count": translations["blacklist_unique_count"],
            "translation_count": len(translations["translations"]),
            "translations_in_frozen_order": translations["translations"],
        },
        "campaign": {
            "row_count": completion["row_count"],
            "finite_grid_cell_count_before_beta_expansion": completion["finite_grid_cell_count_before_beta_expansion"],
            "expanded_cell_count": completion["expanded_cell_count"],
            "second_engine_rows": completion["second_engine_row_indices_zero_based"],
            "geometry_divergence_count": completion["geometry_divergence_count"],
            "q_absolute_observed": {"min": 0.8496224310092052, "max": 0.949869871262966},
        },
        "analysis": {
            "status": analysis["status"],
            "primary": {
                key: analysis["primary"][key]
                for key in (
                    "n_independent_translation_rows", "mean_W", "sd_W_ddof1",
                    "student_t_quantile_0_975_df63", "lower_confidence_bound_nominal",
                    "decision_rule", "coverage_label", "sensitivity_label", "uniformity_label",
                )
            },
            "leave_one_out": {
                key: analysis["leave_one_translation_out"][key]
                for key in (
                    "minimum_mean_W", "maximum_mean_W", "minimum_lcb",
                    "maximum_lcb", "positive_count_of_64",
                )
            },
            "scope_limits": analysis["scope_limits"],
        },
        "actual_costs": {
            "run_elapsed_wall_seconds": costs["elapsed_wall_seconds"],
            "main_engine": {
                "rows": len(main_wall), "wall_seconds_sum": sum(main_wall),
                "wall_seconds_min": min(main_wall), "wall_seconds_max": max(main_wall),
                "wall_seconds_mean": statistics.fmean(main_wall), "cpu_seconds_sum": sum(main_cpu),
            },
            "quickhull_engine": {
                "rows": len(second_wall), "wall_seconds_sum": sum(second_wall),
                "wall_seconds_min": min(second_wall), "wall_seconds_max": max(second_wall),
                "wall_seconds_mean": statistics.fmean(second_wall), "cpu_seconds_sum": sum(second_cpu),
            },
            "run_residual_wall_seconds_oracle_tables_serialization": (
                float(costs["elapsed_wall_seconds"]) - sum(main_wall) - sum(second_wall)
            ),
            "production_peak_memory": None,
            "production_peak_memory_note": "not serialized by the frozen runner; unavailable after process exit",
            "campaign_storage_bytes": tree_bytes(PREP / "campaign_v04"),
            "analysis_storage_bytes": tree_bytes(PREP / "analysis_v04"),
        },
        "artifacts": artifacts,
        "frozen_files": frozen["frozen_files"],
        "publication_executed": False,
        "second_campaign_executed": False,
    }
    OUTPUT.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": result["status"],
        "translation_count": result["randomization"]["translation_count"],
        "primary_status": result["analysis"]["status"],
        "run_elapsed_wall_seconds": result["actual_costs"]["run_elapsed_wall_seconds"],
        "campaign_storage_bytes": result["actual_costs"]["campaign_storage_bytes"],
        "analysis_storage_bytes": result["actual_costs"]["analysis_storage_bytes"],
    }, indent=2))


if __name__ == "__main__":
    main()
