# Réplication indépendante π–morphodynamique — exécution v0.5

Date d’exécution : 27 octobre 2026. Protocole scientifique et code gelés : v0.4.

## Conclusion bornée

La campagne prospective unique est complète : 64 nouvelles translations, 64 lignes principales, 8 contrôles QuickHull, 8 064 cellules et une seule analyse confirmatoire. La règle primaire gelée est satisfaite à `R=512` : la borne Student nominale unilatérale à 97,5 % reste positive après soustraction de la sensibilité empirique `B`.

Décision du code gelé : `FINITE_R512_PREFERENCE_0_32`.

Cette décision établit seulement une préférence moyenne à échelle finie de `β=0,32` sur `β=1/3`, pour les neuf cellules préspecifiées à `R=512`. Elle n’identifie aucun exposant exact, n’établit aucune uniformité angulaire et ne prouve ni ne réfute une loi affine asymptotique.

## LU

- L’archive d’avis v0.5 est intègre : 9 entrées, CRC correct, manifeste interne 8/8, SHA-256 `85e9dec6387c6426e9a658fd24a2dced1ca74cb51053ee6bc857f4b8ef7e4706`.
- Le manifeste gelé original a l’empreinte attendue `023b69c57501ed27ccba892b0e2c2afee88fa1621f711d6c057e3dc0a58f2518`.
- Avant `DRAW`, l’état était exactement `FREEZE → DRAW`, les quatre artefacts futurs étaient absents, et les 28/28 fichiers gelés correspondaient en taille et SHA-256.
- Environnement exact : Python 3.14.5 ; NumPy 2.3.5 ; SciPy 1.17.0 ; mpmath 1.3.0 ; threadpoolctl 3.6.0 ; psutil 7.2.2 ; politique mono-thread du plan.

## EXÉCUTÉ

### Tirage et intégrité

- Une seule graine de 256 bits a été créée après le préflight, sous 64 caractères hexadécimaux minuscules. Elle et les 64 coordonnées figurent intégralement dans `execution_manifest_v05.json` ; la copie consommée par `DRAW` est conservée.
- `DRAW` : 64 appels candidats, 64 coordonnées distinctes, dénominateur `2^20`, provenance `replication_v04_new_draw`, aucune intersection avec les 48 paires historiques exclues.
- Empreinte de la liste ordonnée : `e9e215142a265e98529725efb6877580ed327d74911e156e39685ca87de45e26`.
- `RUN` : statut `COMPLETE_64_ROWS`, 1 152 cellules avant expansion en β, 8 064 cellules après expansion, aucune divergence géométrique.
- QuickHull : 8/8 statuts `PASS_COMPLETE_LAYER_BY_LAYER_SECOND_ENGINE` aux lignes 0, 8, 16, 24, 32, 40, 48 et 56 ; indices, comptes, ensembles de sommets, brackets et digests de couches concordent ; imbrication adjacente non négative.
- Domaine réellement évalué : `q_abs ∈ [0,8496224310092052 ; 0,949869871262966]`, inclus dans le domaine gelé `[0,75 ; 1]`.

### Résultat primaire

`W_j` est la moyenne égale des neuf valeurs `L_(1/3) − L_(0,32) − B` de la trajectoire `j` à `R=512`. Les 64 trajectoires sont les unités indépendantes ; les cellules sont des mesures répétées.

| Quantité | Valeur |
|---|---:|
| `n` | 64 |
| moyenne `W` | `1,1220297693466865e-7` |
| écart-type, `ddof=1` | `8,155211960337087e-9` |
| `t_(0,975;63)` | `1,998340542520741` |
| borne inférieure nominale | `1,101658655980197e-7` |
| règle | borne `> 0` |
| décision | `FINITE_R512_PREFERENCE_0_32` |

La couverture Student est approchée et `B` repose sur des erreurs numériques empiriques, non sur des enveloppes certifiées par intervalles.

Retrait d’une translation : 64/64 bornes restent positives ; moyenne `W` entre `1,1185688525288084e-7` et `1,1245041201225574e-7`, borne entre `1,0990949501982448e-7` et `1,1044196560128936e-7`.

### Secondaires préspecifiés

Les contrastes ci-dessous sont les contrastes bruts `D=L_(1/3)−L_(0,32)` ; un signe positif favorise `0,32`, un signe négatif favorise `1/3`.

| Comparaison par translation | Moyenne | Écart-type | Minimum | Maximum |
|---|---:|---:|---:|---:|
| `D512−D256` | `2,996678230058189e-7` | `1,6666089312746607e-8` | `2,616091973121746e-7` | `3,294900563574601e-7` |
| `R512`, `θ=0` | `1,3072726889308808e-7` | `1,0917735422354254e-8` | `1,044840555970631e-7` | `1,5131583617736668e-7` |
| `R512`, `θ=atan(1/8)` | `3,3280542746017813e-7` | `9,465974576397523e-9` | `3,1343870124263553e-7` | `3,520585413114722e-7` |
| `R512`, `θ=π/4` | `1,1479967155879057e-8` | `1,1686857138723565e-8` | `−1,768018686725476e-8` | `2,9074279989838794e-8` |
| `R512`, `q=0,95` | `2,2505654459811278e-8` | `2,4893985245859643e-9` | `1,74198259448434e-8` | `2,739382342685818e-8` |
| `R512`, `q=0,90` | `1,6493268817811326e-7` | `7,016455550871458e-9` | `1,4796664564907897e-7` | `1,803863747731731e-7` |
| `R512`, `q=0,85` | `2,8757432087122074e-7` | `7,777859326062575e-9` | `2,721139033609485e-7` | `3,073363195693734e-7` |
| `θ=π/4, q=0,95`, `R256` | `−1,5027257781579523e-7` | `1,2292131810527949e-8` | `−1,8389682774414216e-7` | `−1,172418498103927e-7` |
| `θ=π/4, q=0,95`, `R512` | `−4,3416397723056885e-8` | `5,1212941716302125e-9` | `−5,5371616609259335e-8` | `−3,279762941944594e-8` |

La moyenne ne soutient donc pas une préférence uniforme : l’orientation `π/4` est hétérogène et la cellule préspecifiée `π/4, q=0,95` favorise nettement `1/3` aux deux rayons.

### Pertes des sept β

Moyennes descriptives sur `64 translations × 9 cellules` par rayon ; ces 576 valeurs ne sont pas 576 réplications indépendantes.

| β | perte moyenne `R=256` | perte moyenne `R=512` |
|---:|---:|---:|
| 0,30 | `9,373591897077713e-7` | `3,4914111507159565e-7` |
| 0,31 | `4,918071732552042e-7` | `1,35842068619301e-7` |
| 0,32 | `2,0665957696752052e-7` | **`7,943673360475622e-8`** |
| 1/3 | **`6,532930846475006e-8`** | `2,3777428810780464e-7` |
| 0,34 | `9,308401543260638e-8` | `4,1313395068243457e-7` |
| 0,35 | `2,529885174319501e-7` | `7,917222766846683e-7` |
| 0,36 | `5,49941200761393e-7` | `1,3041549653607915e-6` |

Le classement agrégé reproduit le motif préparé : `1/3` est le point de grille le plus favorable à `R=256`, tandis que `0,32` l’est à `R=512`. Aucun optimum entre points n’est revendiqué.

### Oracle et validation numérique

- Qualification empirique sur 1 025 nœuds de `q_abs∈[0,75;1]`, positivité de `ρ` vérifiée pour les deux formulations et tous les β.
- Écarts maximaux de raffinement : support `1,7831069953899714e-11`, coefficient `a3` `3,847880801447454e-12`, temps cible `1,2518874825673265e-12`, résidu `c0` `5,773159728050814e-15` ; contrôle analytique maximal `3,7862685209333335e-11`.
- Sensibilités finales `ε_ref` : environ `3,63e-12` à `3,85e-12` sauf `β=1/3`, pour lequel le plan conserve le plancher pessimiste reçu `2,083506908667765e-9`.
- Ces nombres sont des erreurs empiriques, pas une certification par intervalles.
- Recomputation indépendante sans import du code gelé : `INDEPENDENT_RECOMPUTE_PASS`, 8 064 lignes, 1 152 contrastes, tous les primaires/secondaires et 8 QuickHull concordants ; écart numérique absolu maximal `2,117582368135751e-22`.

### Coûts réels

| Poste | Temps mural | CPU |
|---|---:|---:|
| 64 lignes moteur principal | `829,6492483 s` | `826,15625 s` |
| 8 lignes QuickHull | `376,3376974 s` | `375,03125 s` |
| résidu RUN : oracle + tables + sérialisation | `10,4126995 s` | non séparé |
| RUN complet journalisé | `1 216,3996452 s` (20 min 16,4 s) | non séparé globalement |

Stockage campagne : `207 922 004` octets (`198,29 Mio`) ; stockage analyse : `486 317` octets. Le temps extérieur observé d’`ANALYZE` était d’environ `1,8 s` ; il n’est pas sérialisé par le lanceur gelé.

## INFÉRÉ

- La réplication soutient une préférence moyenne finie de `0,32` à `R=512`, même après la sensibilité empirique et après retrait de chaque translation à tour de rôle.
- L’effet est nettement dépendant de l’orientation et de la contraction. Le primaire positif ne doit pas être lu comme une préférence uniforme.
- Le contraste positif `D512−D256` documente un déplacement fini entre les deux rayons ; il ne permet pas d’extrapoler un exposant limite.
- Le résultat ne transforme pas `0,32` en nouvelle loi et ne réfute pas `β=1/3` comme limite affine possible.

## NON_DISPONIBLE

- Le pic mémoire de la campagne de production n’a pas été sérialisé et ne peut pas être reconstruit après la fin du processus.
- Le coût propre de l’oracle, distinct des tables et de la sérialisation, n’est pas isolé dans le RUN ; seul leur résidu commun est calculable.
- Il n’existe pas de garantie numérique par intervalles.

## Clôture procédurale

État final du lanceur : `ANALYZE → COMPLETE`. Aucune seconde campagne, aucune exclusion, aucune modification du gel, aucune publication automatique. Le mode 4, `H_rot` et l’exploration des anciennes 16 translations n’ont pas été rouverts.
