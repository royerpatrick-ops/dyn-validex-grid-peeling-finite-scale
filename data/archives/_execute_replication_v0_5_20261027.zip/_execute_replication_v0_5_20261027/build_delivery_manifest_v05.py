"""Hash every bounded v0.5 input, control, campaign, analysis and report file."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


WORKSPACE = Path(__file__).resolve().parent.parent
PREP = WORKSPACE / "_prepare_replication_v0_4_20261027"
EXECUTION = WORKSPACE / "_execute_replication_v0_5_20261027"
OUTPUT = EXECUTION / "delivery_manifest_v05.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    if OUTPUT.exists():
        raise FileExistsError(f"refusing to overwrite {OUTPUT}")

    paths = {
        WORKSPACE / "DYN-Avis_Lancement_et_Controles_v0_5.zip",
        WORKSPACE / "_create_replication_controls_v05.py",
        PREP / "frozen_manifest_v04.json",
        PREP / "launcher_state_v04.json",
        PREP / "master_seed_v04.txt",
        PREP / "translations_v04.json",
    }
    paths.update(path for path in (PREP / "campaign_v04").rglob("*") if path.is_file())
    paths.update(path for path in (PREP / "analysis_v04").rglob("*") if path.is_file())
    paths.update(path for path in EXECUTION.rglob("*") if path.is_file() and path != OUTPUT)

    records = []
    for path in sorted(paths, key=lambda item: item.as_posix().lower()):
        records.append({
            "path": path.relative_to(WORKSPACE).as_posix(),
            "bytes": path.stat().st_size,
            "sha256": sha256(path),
        })
    state = json.loads((PREP / "launcher_state_v04.json").read_text(encoding="utf-8"))
    result = {
        "status": "DELIVERY_HASHED_AFTER_SINGLE_COMPLETE_REPLICATION",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "self_excluded": OUTPUT.relative_to(WORKSPACE).as_posix(),
        "launcher_state": {
            "last_completed_action": state["last_completed_action"],
            "next_action": state["next_action"],
            "analysis_status": state["analysis_status"],
        },
        "record_count": len(records),
        "recorded_bytes": sum(record["bytes"] for record in records),
        "records": records,
        "publication_executed": False,
        "second_campaign_executed": False,
    }
    OUTPUT.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": result["status"],
        "record_count": result["record_count"],
        "recorded_bytes": result["recorded_bytes"],
        "launcher_state": result["launcher_state"],
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
