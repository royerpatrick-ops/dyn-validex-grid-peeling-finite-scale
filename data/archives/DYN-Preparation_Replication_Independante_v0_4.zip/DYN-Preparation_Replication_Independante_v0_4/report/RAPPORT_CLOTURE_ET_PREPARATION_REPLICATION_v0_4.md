# Clôture des corrections finies et préparation de la réplication — v0.4

**Patrick Royer — 27 octobre 2026**  
**Statut : protocole gelé avant tirage; aucune nouvelle translation, aucune collecte confirmatoire, aucune publication.**

## Décision courte

La réanalyse des archives est close sans modifier ses conclusions : à taille finie, l'agrégat favorise `β=1/3` à `R=256` et `β=0,32` à `R=512`, avec une hétérogénéité qui interdit toute conclusion uniforme. Le pilote demandé permet de conserver le plan prospectif à **64 nouvelles translations**, mais ne constitue pas un GO : l'acceptation humaine du budget reste requise avant de fournir une graine.

Le protocole, l'oracle, le lanceur et l'analyseur sont gelés sous l'empreinte du manifeste `023b69c57501ed27ccba892b0e2c2afee88fa1621f711d6c057e3dc0a58f2518`. L'état suivant est `DRAW`, mais cette transition n'a pas été exécutée : `master_seed=null`, `translation_list=null`, `new_draw=false`, `new_campaign=false`, `confirmatory_analysis=false`.

## LU, EXÉCUTÉ, INFÉRÉ, NON_DISPONIBLE

| Classe | Contenu |
|---|---|
| **LU** | Avis v0.4, résultats et contrôles v0.3, plan source, P05/P06 et primitives P07/P08. Le profil acquis reste : `R=256` favorise `1/3` en moyenne, `R=512` favorise `0,32`; à `π/4, q=0,95`, `1/3` est favorisé et deux autres cellules `π/4` ne sont pas séparées sous la sensibilité. La correction de normalisation initiale de l'horloge n'explique pas toute sa variation. |
| **EXÉCUTÉ** | Vérification de 21/21 entrées; qualification continue sur 1 025 nœuds; qualifications fixes des primitives; rejeu des deux coordonnées historiques aux deux rayons et trois orientations; comparaison complète Andrew/QuickHull couche par couche; pilote Jarvis borné; contrôle de schéma de l'analyseur; transitions `PREPARE` puis `FREEZE`. |
| **INFÉRÉ** | Budget de la campagne par extrapolation des maxima des deux lignes historiques : `64×principal + 8×QuickHull + références`, avec une marge murale de 1,5 et une marge de stockage de 1,25. La projection Jarvis est une extrapolation de visites, pas un rejeu complet. |
| **NON_DISPONIBLE** | Les 64 translations, leurs enveloppes, leurs `q_abs`, leurs pertes et toute décision confirmatoire. Aucun exposant exact, optimum continu, résultat uniforme en angle, verdict asymptotique ou résultat sur `H_rot` n'est disponible. |

## Plan statistique gelé

Une unité est une translation complète; les 18 cellules géométriques par unité et les 126 pertes associées aux sept valeurs de `β` sont des mesures répétées, pas des réplications indépendantes. Le primaire reste, à `R=512`,

`W_j = moyenne_(3 angles × 3 q) [L_(1/3) - L_(0,32) - B]`,

avec borne unilatérale nominale

`moyenne(W) - t_(0,975;63) sd(W)/sqrt(64) > 0`.

La couverture Student est approchée. `B` est une sensibilité empirique, non une enveloppe certifiée, et comprend la cancellation de la perturbation commune de la cible, les deux erreurs de référence et le terme mixte :

`B = 2 ε_interp |a_ref,1/3-a_ref,0,32|`

`  + 2 |a_peel-a_ref,1/3| ε_ref,1/3 + ε_ref,1/3²`

`  + 2 |a_peel-a_ref,0,32| ε_ref,0,32 + ε_ref,0,32²`

`  + 2 ε_interp (ε_ref,1/3+ε_ref,0,32)`.

Les secondaires préspécifiés sont le contraste apparié `D512-D256`, les résultats par angle et par `q`, la cellule `π/4, q=0,95`, les pertes des sept valeurs `β∈{0,30;0,31;0,32;1/3;0,34;0,35;0,36}` et le retrait d'une traduction. Les agrégats par angle et par `q` sont d'abord ramenés à 64 valeurs de trajectoire. Un primaire positif ne signifierait ni uniformité ni exposant exact.

## Oracle continu gelé

Le domaine est `q_abs∈[0,75;1]`. Pour `R∈{256,512}`, `h0≥0,925` et l'inclusion du disque donnent `q_abs≥0,85(0,925-√2/256)>0,78`, tandis que les cibles imposent `q_abs≤0,95`; le domaine gelé est donc prudent. Les futurs `q_abs=q_hist P_polygone_initial/(2πR)` seront évalués mécaniquement après calcul des enveloppes, sans ajustement de phase, vitesse ou exposant.

L'oracle utilise comme méthode principale la formulation en rayon de courbure/Fourier avec BDF. Les contrôles comprennent un raffinement spatial séparé, un raffinement temporel séparé, une formulation distincte en fonction de support/FD4/Radau, la positivité de `ρ`, les disques pour chaque `β` et l'ellipse pour `β=1/3`. Qualification et production imposent `threadpool_limits(1)` et les mêmes versions de Python, NumPy, SciPy, mpmath et threadpoolctl.

| Contrôle empirique sur 1 025 nœuds | Maximum observé |
|---|---:|
| Écart fonction de support | `1,78311e-11` |
| Écart `a3` | `3,84788e-12` |
| Écart temps-cible | `1,25189e-12` |
| Résidu `c0=q_abs` | `5,77316e-15` |
| Contrôle analytique disque/ellipse | `3,78627e-11` |
| Positivité de `ρ` | vraie pour chaque méthode et chaque `β` |

Les sensibilités `ε_ref` finales sont respectivement `3,62929e-12`, `3,72273e-12`, `3,69027e-12`, `2,08351e-9`, `3,75930e-12`, `3,84788e-12` et `3,70805e-12` sur la grille ordonnée des sept `β`. Pour `β=1/3`, le plancher conservateur reçu de v0.3 domine l'écart nouvellement mesuré. Ces nombres sont des maxima sur une grille finie, sans certification par intervalles ni garantie d'enveloppe continue.

## Pilote historique et intégrité géométrique

Les seules coordonnées rejouées sont `(799351,488675)/2^20` et `(60055,642819)/2^20`; elles sont exclues de la future analyse. Chaque ligne comprend `R=256,512`, `θ∈{0,atan(1/8),π/4}` et `q∈{0,95;0,90;0,85}`.

| Coordonnée entière | Principal mur / CPU | Pic RSS principal | Stockage principal | QuickHull mur / CPU | Pic RSS QuickHull | Couches comparées |
|---|---:|---:|---:|---:|---:|---:|
| `(799351,488675)` | `12,9446 / 12,9063 s` | `111 026 176 o` | `3 209 227 o` | `47,3270 / 47,6875 s` | `129 830 912 o` | `3 858` |
| `(60055,642819)` | `12,9275 / 12,9063 s` | `145 285 120 o` | `3 200 286 o` | `47,3234 / 47,7500 s` | `149 274 624 o` | `3 856` |

Pour les deux lignes, les archives P07/P08 sont reproduites, les ensembles de sommets des deux moteurs concordent à chaque couche, les digests cumulatifs sont égaux, l'imbrication minimale vaut `0` et le résidu maximal de `c0` vaut `1,11e-16`. Les qualifications fixes ajoutent 27 comparaisons d'appartenance initiale, 147 comparaisons de couches à Qhull, la conservation des points alignés non sommets et 112 identités analytiques de Fourier, avec erreur maximale `2,45e-16`.

Le moteur principal et QuickHull ont des boucles de couches, constructions d'enveloppe et retraits distincts. Ils retirent seulement les sommets extrêmes et conservent les points alignés non sommets. Limite maintenue : QuickHull partage les intervalles initiaux produits par la primitive qualifiée; il ne constitue donc pas une seconde validation indépendante de l'appartenance initiale elle-même.

Jarvis exhaustif sur tous les points n'a pas été lancé. Le microbenchmark projette au maximum `101 475,60 s` par ligne complète, soit environ `9,40 jours` pour huit lignes séquentielles, avant même certains surcoûts de recherche; il est remplacé par le rejeu QuickHull entier complet.

## Budget prospectif complet

Le chiffrage utilise, pour chaque moteur, le maximum des deux lignes historiques.

| Composante | Mur séquentiel | CPU | Stockage |
|---|---:|---:|---:|
| 64 lignes principales | `828,454 s` | `826,000 s` | `205 390 528 o` |
| 8 lignes QuickHull | `378,616 s` | `382,000 s` | `8 560 o` |
| Références futures, sept `β` | `0,981 s` | `0,969 s` | `1 048 788 o` projetés |
| **Campagne future, base** | **`1 208,051 s` (20,13 min)** | **`1 208,969 s`** | **`206 447 876 o`** |
| Qualification déjà exécutée | `18,528 s` | `18,859 s` | `933 166 o` |
| **Projet complet, marge** | **`1 839,868 s` (30,66 min)** | **`1 841,742 s`** | **`259 226 303 o`** |

Le pic RSS séquentiel mesuré est `201 818 112 o`. La marge haute applique `×1,5` au temps du projet complet et `×1,25` au stockage; elle ne couvre pas mathématiquement toute variation future de coordonnées. Le coût mesuré ne justifie pas une réduction adaptative de `n=64`; si le plafond local est néanmoins jugé trop bas, une nouvelle version prospective chiffrée doit être décidée avant toute graine.

## Lanceur, analyse et arrêt

Le lanceur impose la chaîne `PREPARE → FREEZE → DRAW → RUN → ANALYZE`. `DRAW`, `RUN` et `ANALYZE` sont fermés par défaut et exigent une autorisation explicite liée à l'empreinte gelée. Le futur tirage utilisera une unique graine hexadécimale minuscule de 256 bits, `PCG64`, le dénominateur `2^20`, les 48 couples historiques exclus exactement et l'acceptation sans remise dans l'ordre généré. Aucune graine ni liste n'existe dans cette livraison.

L'analyseur refuse toute campagne autre que 64 lignes complètes et uniques, les relie par `(tx,ty,D,provenance)`, exige les huit contrôles QuickHull, puis réconcilie le CSV avec les NPZ géométriques et l'artefact oracle. Il vérifie aussi `q_abs`, `c0`, la normalisation `a_m=c_m/c0`, `ε_interp`, les références, les versions d'environnement et l'empreinte du manifeste de complétion. Seul son contrôle de schéma a été exécuté : 8 064 cellules attendues; aucun contraste confirmatoire n'a été calculé.

## Deux corrections documentaires

P05 est un autre échantillon de la même loi dyadique que P06-P19, et non une loi différente. Seules trois trajectoires ont neuf cellules éligibles après exclusion; les treize autres du groupe historique concerné en ont dix.

## Limites et points restant bloquants

- Les erreurs de référence et la marge `B` sont empiriques, non certifiées par intervalles.
- Les deux coordonnées du pilote ne garantissent pas le coût de chaque future translation; la marge est une précaution opérationnelle.
- Trois angles fixes ne sont pas un échantillon de toutes les orientations; une moyenne ne permet aucune conclusion uniforme.
- `β=0,32` reste un comparateur exploratoire fini, pas une nouvelle loi; aucune préférence finie ne prouve ni ne réfute la limite affine.
- Le mode 4, `H_rot`, sa relecture humaine et toute question théorique globale restent séparés.
- Avant toute collecte, il reste uniquement à accepter explicitement le budget, fournir une graine après gel et autoriser `DRAW`; aucun de ces actes n'est accompli ici.

## Livrables et empreintes

- Plan : `plan/PLAN_REPLICATION_INDEPENDANTE_v0_2.md` et `.json`.
- Lanceur : `launcher/replication_launcher_v04.py`; collecte : `launcher/campaign_runner_v04.py`; géométrie : `launcher/geometry_engines_v04.py`.
- Analyse : `analysis/analyze_replication_v04.py`.
- Oracle : `pilot/reference_oracle_v04.py`, `reference_qualification_v04.json`, `reference_grid_v04.npz`.
- Pilote : `pilot/run_historical_cost_pilot_v04.py`, `historical_cost_pilot_v04.json`, deux NPZ principaux, deux contrôles QuickHull et deux projections Jarvis.
- Budget et journal : `pilot/cost_budget_v04.json`, `NOTES_PILOTE_v0_4.md`, `COMMAND_LOG.md`.
- Provenance : `input_manifest_v04.json`; état : `launcher_state_v04.json`; gel : `frozen_manifest_v04.json`.

Empreintes d'entrée : PDF v0.4 `b00d378ba0abcde27ea9435448879afdfc925207e810b291d5151a037554040f`; ZIP v0.4 `90101921cd5fb1bb49b265b6286e5a21b72c053453c02007a87b5793f8cf3de9`. Le PDF interne du ZIP a une empreinte binaire différente, mais son texte extrait et son rendu page par page concordent avec le PDF externe.

Empreintes centrales : protocole `2cba28de3f546342e5eb091774066f8fe74877126e50d4e933e7c09683a8d575`; oracle `890e5cb9e6d8f3317ffe843158f6cbe491f0534743705980630e30ae0e42cf6a`; qualification `0a203c68164b411548732f832e742c5a65329c8f9aa7c72ec4b003848a2c9ad4`; pilote `2763f4cf43776edcd6926fd0a1e372776d59971dac3799704435eeaad70c518e`; analyseur `f77cfac5cde90d51aac948b844dd3aa32cc978945e879d1dae8471072ad305f1`; manifeste gelé `023b69c57501ed27ccba892b0e2c2afee88fa1621f711d6c057e3dc0a58f2518`.

Ce document ne prononce aucun PASS global et n'autorise aucune collecte.
