# Commandes réellement exécutées — préparation v0.4

Environnement : PowerShell, Python `C:\Users\dynagenese\AppData\Local\Python\pythoncore-3.14-64\python.exe`, `PYTHONDONTWRITEBYTECODE=1`.

## Exécutions finales retenues

```powershell
python .\_prepare_replication_v0_4_20261027\pilot\reference_oracle_v04.py --qualify
python .\_prepare_replication_v0_4_20261027\pilot\run_historical_cost_pilot_v04.py --run-historical-pilot
python .\_prepare_replication_v0_4_20261027\pilot\build_cost_budget_v04.py
python .\_prepare_replication_v0_4_20261027\analysis\analyze_replication_v04.py --schema-check
```

Le premier calcul a qualifié l'oracle sur 1 025 nœuds sous `threadpool_limits(1)`. Le second a rejoué uniquement les deux lignes historiques autorisées. Le troisième a composé le budget; le quatrième ne lit aucune donnée scientifique et ne produit aucune décision.

Des requalifications et essais pilotes provisoires ont été lancés pendant la QA, puis invalidés après modification des garde-fous. Deux appels pilotes ont été interrompus; leurs processus résiduels ont été détectés, laissés finir, puis leurs sorties ont été entièrement remplacées par l'exécution finale isolée après vérification qu'aucun processus Python ne subsistait. Ils ne sont ni utilisés ni présentés comme résultats finaux.

Un replay ciblé historique `R=256, theta=0` a aussi été exécuté avant le pilote final pour comparer les deux moteurs : 365 couches, accord exact des sommets et coefficients.

## Actions explicitement non exécutées

- aucune sous-commande `DRAW`;
- aucune sous-commande `RUN` de campagne nouvelle;
- aucune sous-commande `ANALYZE` confirmatoire;
- aucune graine créée ou choisie;
- aucune liste de 64 translations créée;
- aucun nouveau peeling scientifique;
- aucune publication.

