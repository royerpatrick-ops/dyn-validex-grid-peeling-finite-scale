"""Build the conservative v0.4 budget from measured historical-only costs."""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path


HERE = Path(__file__).resolve().parent
PILOT_PATH = HERE / "historical_cost_pilot_v04.json"
QUALIFICATION_PATH = HERE / "reference_qualification_v04.json"
OUTPUT_PATH = HERE / "cost_budget_v04.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    pilot = read_json(PILOT_PATH)
    qualification = read_json(QUALIFICATION_PATH)
    if pilot.get("status") != "COMPLETED_HISTORICAL_ONLY_COST_PILOT":
        raise RuntimeError("historical cost pilot is incomplete")
    if qualification.get("status") != "QUALIFIED_EMPIRICAL_ORACLE_NOT_INTERVAL_CERTIFIED":
        raise RuntimeError("reference qualification is incomplete")
    main = [line["primary_complete_line"] for line in pilot["lines"]]
    second = [line["second_complete_line_quickhull"] for line in pilot["lines"]]
    main_wall = max(row["wall_seconds"] for row in main)
    main_cpu = max(row["cpu_seconds"] for row in main)
    main_storage = max(row["storage_bytes"] for row in main)
    second_wall = max(row["wall_seconds"] for row in second)
    second_cpu = max(row["cpu_seconds"] for row in second)
    second_storage = max(row["storage_bytes"] for row in second)
    reference = qualification["cost"]
    qualification_wall = float(reference["qualification_wall_seconds"])
    qualification_cpu = float(reference["qualification_cpu_seconds"])
    production_wall = float(reference["production_primary_seven_beta_wall_seconds_observed_within_qualification"])
    production_cpu = float(reference["production_primary_seven_beta_cpu_seconds_observed_within_qualification"])
    reference_grid_storage = int(reference["reference_grid_storage_bytes"])
    future_target_count = 64 * 2 * 3 * 3
    qualification_target_count = int(qualification["domain"]["grid_count"])
    production_reference_storage_projection = math.ceil(
        reference_grid_storage * future_target_count / qualification_target_count
    )
    future_wall = 64 * main_wall + 8 * second_wall + production_wall
    future_cpu = 64 * main_cpu + 8 * second_cpu + production_cpu
    total_wall_including_qualification = future_wall + qualification_wall
    total_cpu_including_qualification = future_cpu + qualification_cpu
    future_storage = (
        64 * main_storage + 8 * second_storage + production_reference_storage_projection
    )
    payload = {
        "status": "MEASURED_PROSPECTIVE_BUDGET_NO_GO_DECISION",
        "scientific_collection_executed": False,
        "cost_basis": "maximum of two fixed historical lines for each finite-grid engine",
        "timing_regime": "main and QuickHull measured without tracemalloc; sampled RSS retained",
        "inputs": {
            "historical_pilot_sha256": sha256(PILOT_PATH),
            "reference_qualification_sha256": sha256(QUALIFICATION_PATH),
        },
        "unit_costs": {
            "main_complete_row": {
                "wall_seconds": main_wall,
                "cpu_seconds": main_cpu,
                "peak_rss_bytes": max(row["peak_rss_bytes"] for row in main),
                "incremental_peak_rss_bytes": max(row["incremental_peak_rss_bytes"] for row in main),
                "storage_bytes": main_storage,
            },
            "second_complete_quickhull_row": {
                "wall_seconds": second_wall,
                "cpu_seconds": second_cpu,
                "peak_rss_bytes": max(row["peak_rss_bytes"] for row in second),
                "incremental_peak_rss_bytes": max(row["incremental_peak_rss_bytes"] for row in second),
                "storage_bytes": second_storage,
                "storage_contract": "comparison JSON with cumulative equal layer-record digests; no duplicate secondary vertices",
            },
            "continuous_reference_qualification_already_executed": {
                "wall_seconds": qualification_wall,
                "cpu_seconds": qualification_cpu,
                "peak_rss_bytes": reference["peak_rss_bytes"],
                "storage_bytes": reference_grid_storage,
                "tracemalloc_instrumented": True,
            },
            "continuous_reference_production_future": {
                "wall_seconds_observed_within_qualification": production_wall,
                "cpu_seconds_observed_within_qualification": production_cpu,
                "target_count_future": future_target_count,
                "storage_bytes_projected_from_1025_node_grid": production_reference_storage_projection,
                "projection_not_measurement": True,
            },
        },
        "campaign_formula": "64*main complete row + 8*second complete row + one seven-beta production reference evaluation",
        "future_campaign_base": {
            "wall_seconds_sequential": future_wall,
            "cpu_seconds_sequential": future_cpu,
            "storage_bytes": future_storage,
        },
        "full_project_including_already_executed_reference_qualification": {
            "wall_seconds_sequential": total_wall_including_qualification,
            "cpu_seconds_sequential": total_cpu_including_qualification,
            "high_wall_seconds_factor_1_5": 1.5 * total_wall_including_qualification,
            "high_cpu_seconds_factor_1_5": 1.5 * total_cpu_including_qualification,
            "high_storage_bytes_factor_1_25": 1.25 * (future_storage + reference_grid_storage),
            "sequential_peak_rss_bytes": max(
                max(row["peak_rss_bytes"] for row in main),
                max(row["peak_rss_bytes"] for row in second),
                int(reference["peak_rss_bytes"]),
            ),
        },
        "jarvis_excluded": pilot["jarvis_decision"],
        "decision": "No GO/NO-GO is made here; a human must accept cost before supplying any seed.",
        "limits": [
            "Two historical coordinates may not cover future coordinate-to-coordinate cost variation.",
            "Reference production storage is a conservative linear projection, not a measured campaign artifact.",
            "Wall budget is sequential and excludes scheduler/IO contention beyond the safety factor.",
        ],
    }
    OUTPUT_PATH.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": payload["status"],
        "future_wall_seconds": future_wall,
        "full_high_wall_seconds": payload["full_project_including_already_executed_reference_qualification"]["high_wall_seconds_factor_1_5"],
        "full_high_storage_bytes": payload["full_project_including_already_executed_reference_qualification"]["high_storage_bytes_factor_1_25"],
    }))


if __name__ == "__main__":
    main()

