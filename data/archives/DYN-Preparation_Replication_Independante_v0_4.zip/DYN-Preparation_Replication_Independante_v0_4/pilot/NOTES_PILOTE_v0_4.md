# Notes du pilote historique v0.4

Statut : **pilote de coût historique exécuté; aucune nouvelle translation tirée; aucune campagne ni analyse confirmatoire exécutée**.

## Périmètre exécuté

- Deux coordonnées P06 fixées avant calcul : `(799351,488675)/2^20` et `(60055,642819)/2^20`.
- Pour chaque coordonnée : `R=256,512`, orientations `(1,0)`, `(8,1)`, `(1,1)`, cibles historiques `q=0.95,0.90,0.85`.
- Moteur principal historique complet et second moteur QuickHull entier complet jusqu'à `q=0.85`.
- Jarvis exhaustif sur tous les points non lancé : deux arêtes connues par cellule ont été micro-benchmarkées, puis projetées sur `sum(remaining_points*vertex_count)`.
- Résultats exclus de toute analyse scientifique future.

## Qualifications et intégrité

- Rejeu P07/P08 : `PASS_ARCHIVE_REPLAY` pour les deux lignes. Écarts maximaux : périmètres et poids `0`; coefficients d'extrémité `1.11e-16`; coefficients interpolés `2.22e-16`.
- Qualification fixe `support_shape_engine.py` : 27 comparaisons d'appartenance initiale, 147 comparaisons de couches avec l'oracle plein/Qhull, points alignés non sommets conservés.
- Qualification fixe `polygon_fourier.py` : 112 identités analytiques, erreur maximale `2.4518277472521526e-16`.
- Second moteur : 3 858 couches sur la première ligne et 3 856 sur la seconde; mêmes indices, comptes, sommets canoniques, poids et coefficients que le moteur principal. Minimum exact d'imbrication adjacent : `0` (contact autorisé, aucune valeur négative).
- Digests cumulés des enregistrements de couches, identiques entre routes :
  - ligne 0 : `95f5db1e073cb843047527c7c6638834229296b0404c524933fb0a6f34d2e79f`;
  - ligne 1 : `35b4fa590dccfbd81f8a050f834812780f03bb75d430f4411fe1f1eec6597b2c`.
- Résidu complexe maximal `c0` aux extrémités et après interpolation brute : `1.1102230246251565e-16`.
- Les NPZ principaux conservent les sommets ordonnés, digests canoniques, coefficients bruts, correction explicite de `c0`, `a_global`, `a_shape=a_global exp(+im theta)` et `epsilon_interpolation_a3=bound_c/q_absolute`.

## Coûts mesurés

Les temps principal et QuickHull sont mesurés sans `tracemalloc`; la mémoire est un pic RSS échantillonné. Le stockage QuickHull est le résumé de comparaison avec digest cumulatif, sans duplication de tous les sommets secondaires.

| ligne | principal mur / CPU | pic RSS | stockage principal | QuickHull mur / CPU | pic RSS | stockage contrôle |
|---|---:|---:|---:|---:|---:|---:|
| 0 | 12.9446 s / 12.9063 s | 111 026 176 o | 3 209 227 o | 47.3270 s / 47.6875 s | 129 830 912 o | 1 070 o |
| 1 | 12.9275 s / 12.9063 s | 145 285 120 o | 3 200 286 o | 47.3234 s / 47.7500 s | 149 274 624 o | 1 070 o |

La qualification continue finale utilise 1 025 nœuds, `threadpool_limits(1)`, et prend 18.5278 s mur. L'évaluation primaire des sept β observée à l'intérieur de cette qualification prend 0.98145 s mur. Les erreurs `a3` sont des maxima empiriques sur cette grille finie, jamais des enveloppes de domaine ni des intervalles certifiés. Le maximum inter-méthodes/raffinements vaut `3.847880801447454e-12`; le plancher reçu domine à β=1/3 (`2.083506908667765e-9`).

La projection Jarvis maximale est `101475.60 s` par ligne complète (environ 28.2 h), donc ce moteur n'est pas retenu. Le contrôle complet QuickHull est retenu, avec la limite d'indépendance explicite suivante : les intervalles de lignes initiaux qualifiés sont partagés; construction d'enveloppe, boucle de couches et retrait sont distincts.

## Budget prospectif

Formule : `64*principal + 8*QuickHull + une évaluation continue sept β`.

- base future séquentielle : `1208.051149 s` mur, soit environ 20.1 min;
- borne de planification ×1.5, qualification déjà exécutée incluse : `1839.868401 s`, soit environ 30.7 min;
- stockage haut ×1.25, grille de qualification incluse : `259226302.5 o` (environ 247 MiB);
- pic RSS séquentiel observé maximal : `201818112 o`.

Ces chiffres reposent sur deux coordonnées historiques seulement. Ils ne constituent pas un GO : l'acceptation humaine du coût doit précéder toute graine.

## Empreintes centrales

- protocole : `2cba28de3f546342e5eb091774066f8fe74877126e50d4e933e7c09683a8d575`;
- script pilote : `5295fbd8f8d80b0f31bfbba794939303b0084c292cf531118130d12274a40c68`;
- module géométrique préparé : `18ed0f4903233b9435146a5ee4ccc79044ffc51194e32878ae798f3b1c4aa298`;
- résumé pilote : `2763f4cf43776edcd6926fd0a1e372776d59971dac3799704435eeaad70c518e` avant création de la présente note;
- qualification continue : `0a203c68164b411548732f832e742c5a65329c8f9aa7c72ec4b003848a2c9ad4` avant verrou final du manifeste;
- budget : `8b24e1dc295288ec4c3270b271ad03b3800c3bfa6e5da6c319d361eda5aa5c01` avant verrou final du manifeste.

Les empreintes autoritatives finales figurent dans `frozen_manifest_v04.json` et le manifeste de livraison; les mentions ci-dessus documentent les sorties au moment du pilote.

