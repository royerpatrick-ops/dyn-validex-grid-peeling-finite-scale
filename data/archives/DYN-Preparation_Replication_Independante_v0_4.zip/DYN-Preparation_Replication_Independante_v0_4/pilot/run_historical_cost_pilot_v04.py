"""Historical-only cost pilot for the prepared v0.4 replication.

Exactly two predeclared P06 coordinates are replayed at R=256,512 and the
three prescribed orientations.  No RNG is instantiated and no translation
is generated.  Outputs are cost/integrity diagnostics excluded from any
scientific analysis.

The exhaustive all-point Jarvis route is *not* run.  A bounded known-edge
all-point scan measures its inner-loop rate, which is projected using the
actual sum of remaining-point x hull-vertex counts from the complete primary
replay.  A complete exact-integer QuickHull endpoint replay is measured as a
more efficient proposed second implementation.
"""

from __future__ import annotations

import argparse
import gc
import hashlib
import importlib.util
import json
import math
import platform
import sys
import threading
import time
import tracemalloc
from pathlib import Path

import numpy as np

try:
    import psutil
except ImportError:  # pragma: no cover
    psutil = None


HERE = Path(__file__).resolve().parent
PREP_ROOT = HERE.parent
WORKSPACE = PREP_ROOT.parent
CONFIG_PATH = PREP_ROOT / "protocol_prepare_v04.json"
GEOMETRY_PATH = PREP_ROOT / "launcher" / "geometry_engines_v04.py"
P07_PATH = (
    WORKSPACE
    / "_audit_codex_pi_morphodynamique_20261027"
    / "working_copies"
    / "P07"
    / "DYN-Comparaison_Contraction-Identique_v0_1"
    / "targeted_supports.npz"
)
P08_PATH = (
    WORKSPACE
    / "_audit_codex_pi_morphodynamique_20261027"
    / "working_copies"
    / "P08"
    / "DYN-Extension_Contraction-Identique_R512_v0_1"
    / "extension_supports.npz"
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


geometry = load_module("geometry_engines_v04", GEOMETRY_PATH)


def json_ready(value):
    if isinstance(value, dict):
        return {str(key): json_ready(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_ready(item) for item in value]
    if isinstance(value, np.ndarray):
        return json_ready(value.tolist())
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, complex):
        return {"real": float(value.real), "imag": float(value.imag)}
    return value


def write_json(path: Path, value) -> None:
    path.write_text(json.dumps(json_ready(value), indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


class MemorySampler:
    def __init__(self, interval: float = 0.005):
        self.interval = interval
        self.process = psutil.Process() if psutil else None
        self.baseline = self.process.memory_info().rss if self.process else None
        self.peak = self.baseline
        self.stop_event = threading.Event()
        self.thread = None

    def start(self):
        if self.process is None:
            return

        def sample():
            while not self.stop_event.wait(self.interval):
                try:
                    self.peak = max(self.peak, self.process.memory_info().rss)
                except psutil.Error:
                    return

        self.thread = threading.Thread(target=sample, daemon=True)
        self.thread.start()

    def stop(self):
        if self.process is None:
            return
        self.stop_event.set()
        if self.thread is not None:
            self.thread.join(timeout=1)
        try:
            self.peak = max(self.peak, self.process.memory_info().rss)
        except psutil.Error:
            pass


def measure(function, *, trace_python=True):
    gc.collect()
    sampler = MemorySampler()
    if trace_python:
        tracemalloc.start()
    sampler.start()
    wall_start = time.perf_counter()
    cpu_start = time.process_time()
    result = function()
    cpu = time.process_time() - cpu_start
    wall = time.perf_counter() - wall_start
    if trace_python:
        current, trace_peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()
    else:
        current = trace_peak = None
    sampler.stop()
    return result, {
        "wall_seconds": wall,
        "cpu_seconds": cpu,
        "peak_rss_bytes": sampler.peak,
        "baseline_rss_bytes": sampler.baseline,
        "incremental_peak_rss_bytes": (
            None if sampler.peak is None or sampler.baseline is None else max(0, sampler.peak - sampler.baseline)
        ),
        "peak_tracemalloc_bytes": trace_peak,
        "tracemalloc_current_at_stop_bytes": current,
        "memory_measurement": (
            "psutil sampled RSS plus Python tracemalloc"
            if psutil and trace_python
            else "psutil sampled RSS; tracemalloc disabled because it changed the measured QuickHull regime"
            if psutil
            else "memory peak unavailable; psutil missing and tracemalloc disabled"
        ),
    }


def load_config():
    config = read_json(CONFIG_PATH)
    campaign = config["campaign"]
    if campaign["new_seed"] is not None or campaign["new_translation_list"] is not None:
        raise RuntimeError("Preparation config unexpectedly contains a new seed or translation list")
    coordinates = config["historical_cost_pilot"]["coordinates"]
    if [(row["tx"], row["ty"], row["denominator"]) for row in coordinates] != [
        (799351, 488675, 1048576),
        (60055, 642819, 1048576),
    ]:
        raise RuntimeError("Historical pilot coordinate guard failed")
    if config["historical_cost_pilot"]["radii"] != [256, 512]:
        raise RuntimeError("Historical pilot radius guard failed")
    orientations = config["historical_cost_pilot"]["orientations"]
    if [(row["id"], row["p"], row["q"]) for row in orientations] != [
        ("theta0", 1, 0),
        ("atan_1_8", 8, 1),
        ("pi_over_4", 1, 1),
    ]:
        raise RuntimeError("Historical pilot orientation guard failed")
    if config["historical_cost_pilot"]["q_historical"] != [0.95, 0.90, 0.85]:
        raise RuntimeError("Historical pilot target guard failed")
    return config


def load_npz(path: Path):
    with np.load(path, allow_pickle=False) as archive:
        return {name: archive[name] for name in archive.files}


def archive_lookup(config):
    expected = config["source_provenance"]
    if sha256(P07_PATH) != expected["P07_primitives"]["sha256"]:
        raise RuntimeError("P07 primitive hash mismatch")
    if sha256(P08_PATH) != expected["P08_primitives"]["sha256"]:
        raise RuntimeError("P08 primitive hash mismatch")
    result = {}
    for path in (P07_PATH, P08_PATH):
        archive = load_npz(path)
        modes = tuple(map(int, archive["fourier_modes"]))
        for index in range(len(archive["radii"])):
            radius = int(archive["radii"][index])
            if radius not in (256, 512):
                continue
            tx, ty = map(int, archive["translations_numerators"][index])
            p, q = map(int, archive["orientation_pq"][index])
            key = (tx, ty, radius, p, q)
            endpoint_vertices = []
            for target_index in range(3):
                pair = []
                for endpoint in range(2):
                    start, count = map(
                        int, archive["endpoint_vertex_offsets"][index, target_index, endpoint]
                    )
                    pair.append(np.asarray(archive["vertices_flat"][start : start + count], dtype=np.int64))
                endpoint_vertices.append(pair)
            initial_start, initial_count = map(int, archive["initial_vertex_offsets"][index])
            result[key] = {
                "source_path": str(path),
                "source_sha256": sha256(path),
                "index": index,
                "modes": modes,
                "initial_vertices": np.asarray(
                    archive["vertices_flat"][initial_start : initial_start + initial_count], dtype=np.int64
                ),
                "initial_perimeter": float(archive["initial_perimeter_grid"][index]),
                "endpoint_layers": np.asarray(archive["endpoint_layers"][index], dtype=np.int64),
                "endpoint_vertices": endpoint_vertices,
                "endpoint_coefficients": np.asarray(archive["endpoint_coefficients"][index]),
                "interpolated_coefficients": np.asarray(archive["interpolated_coefficients"][index]),
                "weights_after": np.asarray(archive["weights_after"][index]),
            }
    return result


def compare_to_archive(trajectories, archived):
    maximum = {
        "initial_perimeter_absolute": 0.0,
        "endpoint_perimeter_absolute": 0.0,
        "weight_absolute": 0.0,
        "endpoint_coefficient_absolute": 0.0,
        "interpolated_coefficient_absolute": 0.0,
    }
    exact_initial_vertices = exact_endpoint_vertices = exact_layers = True
    checked_targets = 0
    for trajectory in trajectories:
        key = (
            trajectory["tx"],
            trajectory["ty"],
            trajectory["R"],
            trajectory["p"],
            trajectory["q"],
        )
        reference = archived[key]
        exact_initial_vertices &= geometry.vertex_digest(trajectory["initial_vertices_ordered"]) == geometry.vertex_digest(
            reference["initial_vertices"]
        )
        maximum["initial_perimeter_absolute"] = max(
            maximum["initial_perimeter_absolute"],
            abs(trajectory["initial_perimeter"] - reference["initial_perimeter"]),
        )
        for target_index, target in enumerate(trajectory["targets"]):
            checked_targets += 1
            exact_layers &= [target["n_before"], target["n_after"]] == reference["endpoint_layers"][
                target_index
            ].tolist()
            for endpoint_index, name in enumerate(("before", "after")):
                vertices = target[f"{name}_vertices_canonical"]
                archived_vertices = reference["endpoint_vertices"][target_index][endpoint_index]
                exact_endpoint_vertices &= geometry.vertex_digest(vertices) == geometry.vertex_digest(archived_vertices)
                maximum["endpoint_perimeter_absolute"] = max(
                    maximum["endpoint_perimeter_absolute"],
                    abs(
                        target[f"perimeter_{name}"]
                        - geometry.perimeter([tuple(map(int, value)) for value in archived_vertices])
                    ),
                )
                for archived_position, mode in enumerate(reference["modes"]):
                    position = geometry.MODES.index(mode)
                    maximum["endpoint_coefficient_absolute"] = max(
                        maximum["endpoint_coefficient_absolute"],
                        abs(
                            target[f"{name}_coefficients_raw"][position]
                            - reference["endpoint_coefficients"][target_index, endpoint_index, archived_position]
                        ),
                    )
            maximum["weight_absolute"] = max(
                maximum["weight_absolute"],
                abs(target["weight_after"] - reference["weights_after"][target_index]),
            )
            for archived_position, mode in enumerate(reference["modes"]):
                position = geometry.MODES.index(mode)
                maximum["interpolated_coefficient_absolute"] = max(
                    maximum["interpolated_coefficient_absolute"],
                    abs(
                        target["interpolated_coefficients_raw"][position]
                        - reference["interpolated_coefficients"][target_index, archived_position]
                    ),
                )
    passed = (
        exact_initial_vertices
        and exact_endpoint_vertices
        and exact_layers
        and maximum["initial_perimeter_absolute"] <= 1e-12
        and maximum["endpoint_perimeter_absolute"] <= 1e-12
        and maximum["weight_absolute"] <= 2e-14
        and maximum["endpoint_coefficient_absolute"] <= 2e-13
        and maximum["interpolated_coefficient_absolute"] <= 2e-13
    )
    return {
        "status": "PASS_ARCHIVE_REPLAY" if passed else "FAIL_ARCHIVE_REPLAY",
        "trajectories_checked": len(trajectories),
        "targets_checked": checked_targets,
        "exact_initial_vertex_sets": exact_initial_vertices,
        "exact_endpoint_vertex_sets": exact_endpoint_vertices,
        "exact_target_bracket_layers": exact_layers,
        "maximum_absolute_differences": maximum,
    }


def compare_engines(primary, secondary):
    if len(primary) != len(secondary):
        raise AssertionError("trajectory count mismatch")
    exact_layers = exact_vertices = exact_brackets = exact_counts = True
    maximum_perimeter_relative = 0.0
    maximum_weight_absolute = 0.0
    maximum_coefficient_absolute = {
        "endpoint_raw": 0.0,
        "interpolated_raw": 0.0,
        "interpolated_corrected_c0": 0.0,
        "a_global": 0.0,
        "a_shape": 0.0,
    }
    maximum_c0_residual = 0.0
    minimum_containment = None
    layer_count = 0
    primary_layer_digest = hashlib.sha256()
    secondary_layer_digest = hashlib.sha256()
    for left, right in zip(primary, secondary):
        key_left = (left["R"], left["p"], left["q"], left["tx"], left["ty"])
        key_right = (right["R"], right["p"], right["q"], right["tx"], right["ty"])
        if key_left != key_right:
            raise AssertionError("trajectory pairing mismatch")
        exact_layers &= len(left["layers"]) == len(right["layers"])
        for first, second in zip(left["layers"], right["layers"]):
            layer_count += 1
            exact_layers &= first["n"] == second["n"]
            exact_counts &= (
                first["remaining_points"] == second["remaining_points"]
                and first["vertex_count"] == second["vertex_count"]
            )
            exact_vertices &= first["vertex_sha256"] == second["vertex_sha256"]
            for digest, trajectory, layer in (
                (primary_layer_digest, left, first),
                (secondary_layer_digest, right, second),
            ):
                record = {
                    "R": int(trajectory["R"]),
                    "p": int(trajectory["p"]),
                    "q": int(trajectory["q"]),
                    "tx": int(trajectory["tx"]),
                    "ty": int(trajectory["ty"]),
                    "denominator": int(trajectory["denominator"]),
                    "n": int(layer["n"]),
                    "remaining_points": int(layer["remaining_points"]),
                    "vertex_count": int(layer["vertex_count"]),
                    "perimeter_hex": float(layer["perimeter"]).hex(),
                    "vertex_sha256": layer["vertex_sha256"],
                    "minimum_containment_cross_from_previous": layer[
                        "minimum_containment_cross_from_previous"
                    ],
                }
                digest.update(
                    (json.dumps(record, sort_keys=True, separators=(",", ":")) + "\n").encode("ascii")
                )
            for value in (
                first["minimum_containment_cross_from_previous"],
                second["minimum_containment_cross_from_previous"],
            ):
                if value is not None:
                    minimum_containment = value if minimum_containment is None else min(minimum_containment, value)
            maximum_perimeter_relative = max(
                maximum_perimeter_relative,
                abs(first["perimeter"] - second["perimeter"]) / max(1.0, abs(first["perimeter"])),
            )
        for first, second in zip(left["targets"], right["targets"]):
            exact_brackets &= (
                first["n_before"] == second["n_before"]
                and first["n_after"] == second["n_after"]
            )
            maximum_weight_absolute = max(
                maximum_weight_absolute, abs(first["weight_after"] - second["weight_after"])
            )
            for name in ("before", "after"):
                if first[f"{name}_vertex_sha256"] != second[f"{name}_vertex_sha256"]:
                    exact_vertices = False
                maximum_coefficient_absolute["endpoint_raw"] = max(
                    maximum_coefficient_absolute["endpoint_raw"],
                    float(np.max(np.abs(
                        first[f"{name}_coefficients_raw"] - second[f"{name}_coefficients_raw"]
                    ))),
                )
            for key, field in (
                ("interpolated_raw", "interpolated_coefficients_raw"),
                ("interpolated_corrected_c0", "interpolated_coefficients_corrected_c0"),
                ("a_global", "a_global"),
                ("a_shape", "a_shape_exp_plus_i_m_theta"),
            ):
                maximum_coefficient_absolute[key] = max(
                    maximum_coefficient_absolute[key],
                    float(np.max(np.abs(first[field] - second[field]))),
                )
            maximum_c0_residual = max(
                maximum_c0_residual,
                first["before_c0_complex_residual"],
                first["after_c0_complex_residual"],
                first["interpolated_c0_complex_residual_before_correction"],
                second["before_c0_complex_residual"],
                second["after_c0_complex_residual"],
                second["interpolated_c0_complex_residual_before_correction"],
            )
    primary_layer_sha256 = primary_layer_digest.hexdigest()
    secondary_layer_sha256 = secondary_layer_digest.hexdigest()
    passed = (
        exact_layers
        and exact_vertices
        and exact_brackets
        and exact_counts
        and maximum_perimeter_relative <= 1e-12
        and maximum_weight_absolute <= 1e-12
        and max(maximum_coefficient_absolute.values()) <= 1e-12
        and maximum_c0_residual <= 5e-14
        and minimum_containment is not None
        and minimum_containment >= 0
        and primary_layer_sha256 == secondary_layer_sha256
    )
    return {
        "status": "PASS_COMPLETE_LAYER_BY_LAYER_SECOND_ENGINE" if passed else "FAIL_SECOND_ENGINE",
        "layers_compared": layer_count,
        "exact_layer_indices": exact_layers,
        "exact_remaining_and_vertex_counts": exact_counts,
        "exact_vertex_sets": exact_vertices,
        "exact_target_brackets": exact_brackets,
        "maximum_perimeter_relative_difference": maximum_perimeter_relative,
        "maximum_weight_absolute_difference": maximum_weight_absolute,
        "maximum_coefficient_absolute_differences": maximum_coefficient_absolute,
        "maximum_c0_target_residual": maximum_c0_residual,
        "minimum_exact_adjacent_containment_cross": minimum_containment,
        "cumulative_layer_record_sha256_primary": primary_layer_sha256,
        "cumulative_layer_record_sha256_secondary": secondary_layer_sha256,
        "cumulative_layer_record_sha256_equal": primary_layer_sha256 == secondary_layer_sha256,
        "relative_tolerance_contract": 1e-12,
        "independence_limit": (
            "QuickHull, layer driver and removal are independent; qualified initial row intervals are shared"
        ),
    }


def save_line_npz(path: Path, trajectories):
    layer_trajectory = []
    layer_n = []
    remaining = []
    vertex_count = []
    layer_perimeter = []
    layer_digest = []
    layer_vertices = []
    layer_offsets = []
    layer_cursor = 0
    layer_containment = []
    endpoint_vertices = []
    endpoint_offsets = []
    endpoint_cursor = 0
    endpoint_digest = []
    endpoint_layers = []
    endpoint_perimeters = []
    endpoint_coefficients_raw = []
    interpolated_coefficients_raw = []
    interpolated_coefficients_corrected = []
    a_global = []
    a_shape = []
    before_c0_residual = []
    after_c0_residual = []
    interpolated_c0_residual = []
    weights = []
    q_absolute = []
    interpolation_bounds = []
    interpolation_a_bounds = []
    for trajectory_index, trajectory in enumerate(trajectories):
        for layer in trajectory["layers"]:
            layer_trajectory.append(trajectory_index)
            layer_n.append(layer["n"])
            remaining.append(layer["remaining_points"])
            vertex_count.append(layer["vertex_count"])
            layer_perimeter.append(layer["perimeter"])
            layer_digest.append(layer["vertex_sha256"])
            values = np.asarray(layer["vertices_ordered"], dtype=np.int64)
            layer_offsets.append((layer_cursor, len(values)))
            layer_vertices.append(values)
            layer_cursor += len(values)
            value = layer["minimum_containment_cross_from_previous"]
            layer_containment.append(np.iinfo(np.int64).min if value is None else int(value))
        trajectory_offsets = []
        trajectory_layers = []
        trajectory_perimeters = []
        trajectory_digest = []
        trajectory_coefficients_raw = []
        trajectory_interpolated_raw = []
        trajectory_interpolated_corrected = []
        trajectory_a_global = []
        trajectory_a_shape = []
        trajectory_before_c0 = []
        trajectory_after_c0 = []
        trajectory_interpolated_c0 = []
        trajectory_weights = []
        trajectory_q = []
        trajectory_bounds = []
        trajectory_a_bounds = []
        for target in trajectory["targets"]:
            pair_offsets = []
            pair_digests = []
            pair_coefficients = []
            for name in ("before", "after"):
                values = np.asarray(target[f"{name}_vertices_ordered"], dtype=np.int64)
                pair_offsets.append((endpoint_cursor, len(values)))
                endpoint_vertices.append(values)
                endpoint_cursor += len(values)
                pair_digests.append(target[f"{name}_vertex_sha256"])
                pair_coefficients.append(target[f"{name}_coefficients_raw"])
            trajectory_offsets.append(pair_offsets)
            trajectory_digest.append(pair_digests)
            trajectory_layers.append((target["n_before"], target["n_after"]))
            trajectory_perimeters.append((target["perimeter_before"], target["perimeter_after"]))
            trajectory_coefficients_raw.append(pair_coefficients)
            trajectory_interpolated_raw.append(target["interpolated_coefficients_raw"])
            trajectory_interpolated_corrected.append(target["interpolated_coefficients_corrected_c0"])
            trajectory_a_global.append(target["a_global"])
            trajectory_a_shape.append(target["a_shape_exp_plus_i_m_theta"])
            trajectory_before_c0.append(target["before_c0_complex_residual"])
            trajectory_after_c0.append(target["after_c0_complex_residual"])
            trajectory_interpolated_c0.append(
                target["interpolated_c0_complex_residual_before_correction"]
            )
            trajectory_weights.append(target["weight_after"])
            trajectory_q.append(target["q_absolute"])
            trajectory_bounds.append(target["interpolation_coefficient_bound"])
            trajectory_a_bounds.append(target["epsilon_interpolation_a3"])
        endpoint_offsets.append(trajectory_offsets)
        endpoint_digest.append(trajectory_digest)
        endpoint_layers.append(trajectory_layers)
        endpoint_perimeters.append(trajectory_perimeters)
        endpoint_coefficients_raw.append(trajectory_coefficients_raw)
        interpolated_coefficients_raw.append(trajectory_interpolated_raw)
        interpolated_coefficients_corrected.append(trajectory_interpolated_corrected)
        a_global.append(trajectory_a_global)
        a_shape.append(trajectory_a_shape)
        before_c0_residual.append(trajectory_before_c0)
        after_c0_residual.append(trajectory_after_c0)
        interpolated_c0_residual.append(trajectory_interpolated_c0)
        weights.append(trajectory_weights)
        q_absolute.append(trajectory_q)
        interpolation_bounds.append(trajectory_bounds)
        interpolation_a_bounds.append(trajectory_a_bounds)
    np.savez_compressed(
        path,
        radii=np.asarray([row["R"] for row in trajectories], dtype=np.int64),
        orientation_pq=np.asarray([[row["p"], row["q"]] for row in trajectories], dtype=np.int64),
        orientation_theta=np.asarray([math.atan2(row["q"], row["p"]) for row in trajectories]),
        translations=np.asarray([[row["tx"], row["ty"], row["denominator"]] for row in trajectories], dtype=np.int64),
        initial_point_count=np.asarray([row["initial_point_count"] for row in trajectories], dtype=np.int64),
        initial_perimeter=np.asarray([row["initial_perimeter"] for row in trajectories]),
        initial_vertex_sha256=np.asarray([row["initial_vertex_sha256"] for row in trajectories]),
        minimum_all_adjacent_layer_containment_cross=np.asarray(
            [row["minimum_all_adjacent_layer_containment_cross"] for row in trajectories], dtype=np.int64
        ),
        layer_trajectory=np.asarray(layer_trajectory, dtype=np.int64),
        layer_n=np.asarray(layer_n, dtype=np.int64),
        layer_remaining_points=np.asarray(remaining, dtype=np.int64),
        layer_vertex_count=np.asarray(vertex_count, dtype=np.int64),
        layer_perimeter=np.asarray(layer_perimeter),
        layer_vertex_sha256=np.asarray(layer_digest),
        layer_vertex_offsets=np.asarray(layer_offsets, dtype=np.int64),
        layer_vertices_ordered_flat=np.concatenate(layer_vertices, axis=0),
        layer_minimum_containment_cross_from_previous=np.asarray(layer_containment, dtype=np.int64),
        layer0_containment_sentinel=np.asarray(np.iinfo(np.int64).min, dtype=np.int64),
        target_q_historical=np.asarray(geometry.TARGETS),
        target_q_absolute=np.asarray(q_absolute),
        endpoint_layers=np.asarray(endpoint_layers, dtype=np.int64),
        endpoint_perimeters=np.asarray(endpoint_perimeters),
        endpoint_vertex_offsets=np.asarray(endpoint_offsets, dtype=np.int64),
        endpoint_vertices_ordered_flat=np.concatenate(endpoint_vertices, axis=0),
        endpoint_vertex_sha256=np.asarray(endpoint_digest),
        fourier_modes=np.asarray(geometry.MODES, dtype=np.int64),
        endpoint_coefficients_raw=np.asarray(endpoint_coefficients_raw),
        interpolated_coefficients_raw=np.asarray(interpolated_coefficients_raw),
        interpolated_coefficients_corrected_c0=np.asarray(interpolated_coefficients_corrected),
        a_global=np.asarray(a_global),
        a_shape_exp_plus_i_m_theta=np.asarray(a_shape),
        before_c0_complex_residual=np.asarray(before_c0_residual),
        after_c0_complex_residual=np.asarray(after_c0_residual),
        interpolated_c0_complex_residual_before_correction=np.asarray(interpolated_c0_residual),
        weights_after=np.asarray(weights),
        interpolation_coefficient_bounds=np.asarray(interpolation_bounds),
        epsilon_interpolation_a3=np.asarray(interpolation_a_bounds),
    )


def run_line(config, coordinate, engine, fourier, method):
    allowed_coordinates = [
        (int(row["tx"]), int(row["ty"]), int(row["denominator"]))
        for row in config["historical_cost_pilot"]["coordinates"]
    ]
    supplied_coordinate = (
        int(coordinate["tx"]), int(coordinate["ty"]), int(coordinate["denominator"])
    )
    if allowed_coordinates != [(799351, 488675, 1048576), (60055, 642819, 1048576)]:
        raise RuntimeError("pilot coordinate allowlist was altered")
    if supplied_coordinate not in allowed_coordinates:
        raise RuntimeError("coordinate outside historical pilot allowlist")
    if method == "main_monotone":
        runner = geometry.run_primary_trajectory
    elif method == "second_quickhull_endpoints":
        runner = geometry.run_second_quickhull_trajectory
    else:
        raise ValueError("method outside historical pilot allowlist")
    values = []
    for radius in config["historical_cost_pilot"]["radii"]:
        for orientation in config["historical_cost_pilot"]["orientations"]:
            values.append(
                runner(
                    radius=radius,
                    p=int(orientation["p"]),
                    q=int(orientation["q"]),
                    tx=int(coordinate["tx"]),
                    ty=int(coordinate["ty"]),
                    denominator=int(coordinate["denominator"]),
                    engine=engine,
                    fourier=fourier,
                )
            )
    if len(values) != 6:
        raise AssertionError("historical pilot line must contain exactly six trajectories")
    expected_keys = [
        (radius, int(orientation["p"]), int(orientation["q"]))
        for radius in (256, 512)
        for orientation in config["historical_cost_pilot"]["orientations"]
    ]
    actual_keys = [(row["R"], row["p"], row["q"]) for row in values]
    if actual_keys != expected_keys:
        raise AssertionError("historical pilot trajectory key/order mismatch")
    for row in values:
        if len(row["targets"]) != 3:
            raise AssertionError("trajectory does not contain exactly three targets")
        if [target["q_historical"] for target in row["targets"]] != list(geometry.TARGETS):
            raise AssertionError("trajectory target allowlist/order mismatch")
        layer_containment = [
            layer["minimum_containment_cross_from_previous"]
            for layer in row["layers"][1:]
        ]
        if not layer_containment or min(layer_containment) < 0:
            raise AssertionError("all adjacent layers must satisfy exact nesting")
        if min(layer_containment) != row["minimum_all_adjacent_layer_containment_cross"]:
            raise AssertionError("global adjacent-layer containment summary mismatch")
    return values


def scan_known_hull_edges_all_points(rows, hull, edge_count: int):
    """Bounded exact all-point scans of known CCW hull edges.

    This measures the dominant scan kernel but does not execute Jarvis hull
    discovery.  A full all-point Jarvis run is explicitly prohibited here.
    """
    if edge_count <= 0 or edge_count > len(hull):
        raise ValueError(edge_count)
    visits = 0
    collinear = 0
    for edge_index in range(edge_count):
        a = hull[edge_index]
        b = hull[(edge_index + 1) % len(hull)]
        for y, (lo, hi) in rows.items():
            for x in range(int(lo), int(hi) + 1):
                value = geometry.cross_int(a, b, (x, int(y)))
                visits += 1
                if value < 0:
                    raise AssertionError("known hull edge failed all-point half-plane scan")
                if value == 0:
                    collinear += 1
    return {"point_visits": visits, "collinear_visits": collinear, "edges_scanned": edge_count}


def jarvis_probe_line(config, coordinate, engine, primary):
    edge_count = int(config["historical_cost_pilot"]["jarvis_probe"]["exact_all_point_scans_per_initial_cell"])
    cells = []
    total_sample_visits = 0
    total_projected_visits = 0
    sample_wall = 0.0
    sample_cpu = 0.0
    primary_by_key = {(row["R"], row["p"], row["q"]): row for row in primary}
    for radius in config["historical_cost_pilot"]["radii"]:
        for orientation in config["historical_cost_pilot"]["orientations"]:
            p, q = int(orientation["p"]), int(orientation["q"])
            rows = engine.initial_rows(
                radius,
                p,
                q,
                int(coordinate["tx"]),
                int(coordinate["ty"]),
                int(coordinate["denominator"]),
            )
            hull = engine.hull(engine.endpoints(rows))
            started_wall = time.perf_counter()
            started_cpu = time.process_time()
            scan = scan_known_hull_edges_all_points(rows, hull, edge_count)
            wall = time.perf_counter() - started_wall
            cpu = time.process_time() - started_cpu
            trajectory = primary_by_key[(radius, p, q)]
            projected_visits = sum(
                int(layer["remaining_points"]) * int(layer["vertex_count"])
                for layer in trajectory["layers"]
            )
            total_sample_visits += scan["point_visits"]
            total_projected_visits += projected_visits
            sample_wall += wall
            sample_cpu += cpu
            cells.append(
                {
                    "R": radius,
                    "orientation": orientation["id"],
                    "initial_points": geometry.row_point_count(rows),
                    "initial_vertices": len(hull),
                    "layers_through_q085": len(trajectory["layers"]),
                    "sample": scan,
                    "sample_wall_seconds": wall,
                    "sample_cpu_seconds": cpu,
                    "projected_all_point_visits_full_trajectory": projected_visits,
                    "projected_wall_seconds_full_trajectory": wall / scan["point_visits"] * projected_visits,
                    "projected_cpu_seconds_full_trajectory": cpu / scan["point_visits"] * projected_visits,
                }
            )
    projected_wall = sample_wall / total_sample_visits * total_projected_visits
    projected_cpu = sample_cpu / total_sample_visits * total_projected_visits
    return {
        "status": "PROHIBITIVE_NOT_RUN_FULL",
        "method": "all-point Jarvis known-edge exact-scan microbenchmark; no full hull discovery",
        "full_run_allowed_by_protocol": False,
        "cells": cells,
        "sample_point_visits": total_sample_visits,
        "projected_all_point_visits_complete_line": total_projected_visits,
        "sample_wall_seconds": sample_wall,
        "sample_cpu_seconds": sample_cpu,
        "projected_wall_seconds_complete_line": projected_wall,
        "projected_cpu_seconds_complete_line": projected_cpu,
        "projection_caveat": (
            "linear inner-loop projection from known-edge scans; excludes Jarvis candidate-update overhead and is not a full execution"
        ),
    }


def output_hashes(paths):
    return {
        path.name: {"sha256": sha256(path), "bytes": path.stat().st_size}
        for path in paths
        if path.exists()
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--run-historical-pilot",
        action="store_true",
        help="execute only the fixed two-coordinate historical cost pilot",
    )
    args = parser.parse_args()
    if not args.run_historical_pilot:
        raise SystemExit(
            "Refusing implicit execution; pass --run-historical-pilot for the fixed historical pilot only"
        )

    config = load_config()
    engine, fourier = geometry.load_historical_modules()
    quickhull_qualification = geometry.qualify_quickhull()
    archived = archive_lookup(config)
    coordinates = config["historical_cost_pilot"]["coordinates"]
    line_results = []
    created_paths = []

    total_started = time.perf_counter()
    engine_qualification, engine_qualification_cost = measure(
        engine.qualification, trace_python=False
    )
    fourier_qualification, fourier_qualification_cost = measure(
        fourier.qualification, trace_python=False
    )
    if (
        engine_qualification.get("status") != "PASS_QUALIFIED_SMOOTH_SUPPORT_GEOMETRY"
        or engine_qualification.get("source_sha256") != sha256(geometry.ENGINE_PATH)
    ):
        raise AssertionError("historical geometry-source qualification failed")
    if (
        fourier_qualification.get("status")
        != "PASS_ANALYTIC_POLYGON_SUPPORT_FOURIER_QUALIFICATION"
        or fourier_qualification.get("source_sha256") != sha256(geometry.FOURIER_PATH)
    ):
        raise AssertionError("historical Fourier-source qualification failed")
    source_qualification_path = HERE / "historical_source_qualifications_v04.json"
    write_json(
        source_qualification_path,
        {
            "geometry": engine_qualification,
            "geometry_cost": engine_qualification_cost,
            "polygon_fourier": fourier_qualification,
            "polygon_fourier_cost": fourier_qualification_cost,
            "scope": "fixed module qualifications only; no new scientific translation",
        },
    )
    created_paths.append(source_qualification_path)

    for line_index, coordinate in enumerate(coordinates):
        primary, primary_cost = measure(
            lambda coordinate=coordinate: run_line(
                config, coordinate, engine, fourier, "main_monotone"
            ),
            trace_python=False,
        )
        main_path = HERE / f"historical_line_{line_index:02d}_main.npz"
        serialize_started = time.perf_counter()
        save_line_npz(main_path, primary)
        primary_cost["serialization_wall_seconds"] = time.perf_counter() - serialize_started
        primary_cost["storage_bytes"] = main_path.stat().st_size
        primary_cost["artifact_sha256"] = sha256(main_path)
        created_paths.append(main_path)
        archive_check = compare_to_archive(primary, archived)
        if archive_check["status"] != "PASS_ARCHIVE_REPLAY":
            raise AssertionError(archive_check)

        secondary, secondary_cost = measure(
            lambda coordinate=coordinate: run_line(
                config, coordinate, engine, fourier, "second_quickhull_endpoints"
            ),
            trace_python=False,
        )
        second_check = compare_engines(primary, secondary)
        if second_check["status"] != "PASS_COMPLETE_LAYER_BY_LAYER_SECOND_ENGINE":
            raise AssertionError(second_check)
        serialize_started = time.perf_counter()
        second_check_path = HERE / f"historical_line_{line_index:02d}_quickhull_check.json"
        write_json(second_check_path, second_check)
        secondary_cost["serialization_wall_seconds"] = time.perf_counter() - serialize_started
        secondary_cost["storage_bytes"] = (
            second_check_path.stat().st_size
        )
        secondary_cost["check_artifact_sha256"] = sha256(second_check_path)
        secondary_cost["storage_contract"] = (
            "comparison summary with equal cumulative layer-record digests; secondary ordered vertices are not retained"
        )
        created_paths.append(second_check_path)

        jarvis, jarvis_cost = measure(
            lambda coordinate=coordinate, primary=primary: jarvis_probe_line(
                config, coordinate, engine, primary
            ),
            trace_python=False,
        )
        jarvis.update(
            {
                "measured_wrapper_wall_seconds": jarvis_cost["wall_seconds"],
                "measured_wrapper_cpu_seconds": jarvis_cost["cpu_seconds"],
                "peak_rss_bytes": jarvis_cost["peak_rss_bytes"],
                "incremental_peak_rss_bytes": jarvis_cost["incremental_peak_rss_bytes"],
                "peak_tracemalloc_bytes": jarvis_cost["peak_tracemalloc_bytes"],
            }
        )
        jarvis_path = HERE / f"historical_line_{line_index:02d}_jarvis_projection.json"
        write_json(jarvis_path, jarvis)
        created_paths.append(jarvis_path)

        line_results.append(
            {
                "line_index": line_index,
                "coordinate": coordinate,
                "trajectories": 6,
                "primary_complete_line": primary_cost,
                "primary_archive_replay": archive_check,
                "second_complete_line_quickhull": secondary_cost,
                "second_engine_comparison": second_check,
                "jarvis_all_point_bounded_projection": jarvis,
                "layer_counts": {
                    f"R{row['R']}_{row['p']}_{row['q']}": len(row["layers"])
                    for row in primary
                },
            }
        )

    max_primary_wall = max(row["primary_complete_line"]["wall_seconds"] for row in line_results)
    max_primary_cpu = max(row["primary_complete_line"]["cpu_seconds"] for row in line_results)
    max_primary_storage = max(row["primary_complete_line"]["storage_bytes"] for row in line_results)
    max_second_wall = max(row["second_complete_line_quickhull"]["wall_seconds"] for row in line_results)
    max_second_cpu = max(row["second_complete_line_quickhull"]["cpu_seconds"] for row in line_results)
    max_second_storage = max(row["second_complete_line_quickhull"]["storage_bytes"] for row in line_results)
    max_jarvis_wall = max(
        row["jarvis_all_point_bounded_projection"]["projected_wall_seconds_complete_line"]
        for row in line_results
    )

    summary_path = HERE / "historical_cost_pilot_v04.json"
    summary = {
        "status": "COMPLETED_HISTORICAL_ONLY_COST_PILOT",
        "historical_cost_pilot_executed": True,
        "historical_peeling_replay_executed": True,
        "new_translation_draw_executed": False,
        "new_scientific_collection_executed": False,
        "confirmatory_analysis_executed": False,
        "new_translation_drawn": False,
        "new_seed_generated": False,
        "new_campaign_row_run": False,
        "historical_coordinates_only": True,
        "excluded_from_scientific_analysis": True,
        "config_sha256": sha256(CONFIG_PATH),
        "source_sha256": sha256(Path(__file__).resolve()),
        "geometry_module_sha256": sha256(GEOMETRY_PATH),
        "historical_engine_sha256": sha256(geometry.ENGINE_PATH),
        "historical_fourier_sha256": sha256(geometry.FOURIER_PATH),
        "quickhull_qualification": quickhull_qualification,
        "historical_source_qualifications": {
            "artifact": source_qualification_path.name,
            "artifact_sha256": sha256(source_qualification_path),
            "geometry_status": engine_qualification["status"],
            "geometry_initial_full_grid_comparisons": engine_qualification[
                "initial_full_grid_comparisons"
            ],
            "geometry_layer_full_grid_qhull_comparisons": engine_qualification[
                "layer_full_grid_qhull_comparisons"
            ],
            "geometry_collinear_nonvertices_retained": engine_qualification[
                "collinear_nonvertices_retained"
            ],
            "geometry_cost": engine_qualification_cost,
            "fourier_status": fourier_qualification["status"],
            "fourier_analytic_identity_checks": fourier_qualification[
                "analytic_identity_checks"
            ],
            "fourier_max_analytic_identity_error": fourier_qualification[
                "max_analytic_identity_error"
            ],
            "fourier_cost": fourier_qualification_cost,
        },
        "lines": line_results,
        "budget_components_before_reference_cost": {
            "main_64_rows_base_wall_seconds": 64 * max_primary_wall,
            "main_64_rows_base_cpu_seconds": 64 * max_primary_cpu,
            "second_8_rows_quickhull_base_wall_seconds": 8 * max_second_wall,
            "second_8_rows_quickhull_base_cpu_seconds": 8 * max_second_cpu,
            "combined_base_wall_seconds_sequential": 64 * max_primary_wall + 8 * max_second_wall,
            "combined_high_wall_seconds_factor_1_5": 1.5 * (64 * max_primary_wall + 8 * max_second_wall),
            "main_storage_64_rows_bytes": 64 * max_primary_storage,
            "second_storage_8_rows_bytes": 8 * max_second_storage,
            "combined_high_storage_bytes_factor_1_25": 1.25
            * (64 * max_primary_storage + 8 * max_second_storage),
            "reference_cost_pending_separate_qualification": True,
        },
        "jarvis_decision": {
            "status": "PROHIBITIVE_NOT_RUN_FULL",
            "maximum_projected_wall_seconds_per_complete_line": max_jarvis_wall,
            "projected_8_line_wall_seconds_sequential": 8 * max_jarvis_wall,
            "replacement": "complete exact-integer QuickHull endpoint replay",
            "replacement_is_full_layer_replay": True,
            "replacement_initial_membership_independence_limit": (
                "shares qualified initial row intervals with the main engine"
            ),
        },
        "elapsed_wall_seconds_total_pilot": time.perf_counter() - total_started,
        "environment": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "platform": platform.platform(),
            "psutil": None if psutil is None else psutil.__version__,
        },
        "limits": [
            "Two historical coordinates only; costs may vary on future coordinates.",
            "Jarvis is a bounded inner-loop projection, not a full execution.",
            "QuickHull is fully replayed but shares initial membership row intervals.",
            "Peak RSS is sampled and can miss a short-lived maximum.",
            "No scientific contrast is computed from this cost pilot."
        ],
    }
    write_json(summary_path, summary)
    summary["outputs"] = output_hashes(created_paths)
    write_json(summary_path, summary)
    # The self-hash is deliberately excluded to avoid recursive hashing.
    print(
        json.dumps(
            {
                "status": summary["status"],
                "primary_max_wall_seconds_per_line": max_primary_wall,
                "quickhull_max_wall_seconds_per_line": max_second_wall,
                "jarvis_projected_max_wall_seconds_per_line": max_jarvis_wall,
                "elapsed_wall_seconds_total_pilot": summary["elapsed_wall_seconds_total_pilot"],
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
