"""Build the bounded v0.4 input manifest without modifying source archives."""

from __future__ import annotations

import hashlib
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path


DELIVERY = Path(__file__).resolve().parents[1]
WORKSPACE = DELIVERY.parent
OUTPUT = DELIVERY / "input_manifest_v04.json"

EXPECTED = {
    "DYN-Bilan_Corrections_Finies_v0_4.pdf": "b00d378ba0abcde27ea9435448879afdfc925207e810b291d5151a037554040f",
    "DYN-Bilan_et_Controles_Corrections_Finies_v0_4.zip": "90101921cd5fb1bb49b265b6286e5a21b72c053453c02007a87b5793f8cf3de9",
    "DYN-Prompt_Codex_Pilote_Replication_v0_4.txt": "d72a123b0222e7d309a385643d2207860254cf443a4030c21827e322fe9d60e7",
    "_reanalyze_corrections_finies_v0_3_20261027.zip": "500e6d2f480994b512d4c460cbb3a5993edbe8d571e93548bb2875c5ac6d869c",
    "_reanalyze_corrections_finies_v0_3_20261027/replication_plan/PLAN_REPLICATION_INDEPENDANTE_v0_1.md": "a98d8523cd60ca728017a83ee42ea6a55cedab113eb0c740f7a8b621c19dedb2",
    "_reanalyze_corrections_finies_v0_3_20261027/replication_plan/PLAN_REPLICATION_INDEPENDANTE_v0_1.json": "befdfeacc103f6e26065226119f539185b064ce57439a59a311ee3773342fbd3",
    "_reanalyze_corrections_finies_v0_3_20261027/beta_profile/reanalyze_beta_profile_v03.py": "d18a94ad1ea5c79e3f32f4663ae778d7b24db434723c4269df226a15b9324f60",
    "_reanalyze_corrections_finies_v0_3_20261027/beta_profile/reference_qualification.json": "c94c09a3dbb6e125f8200cb5cc2d5fe932683573405188e3d6e302a32088fdc0",
    "_reanalyze_corrections_finies_v0_3_20261027/validation_finale_v03.json": "1d254fe2dbf3842297e97639ebe0302d97c826715da42f5393511a753eb940c4",
    "_audit_codex_pi_morphodynamique_20261027/working_copies/P05/DYN-Replique_Epluchage_Horloge-Gelee_v0_1/draws.csv": "06811464367ebbeeeaffc656b0fe2ce2018315e73ab7eaf493c7677f8d321b60",
    "_audit_codex_pi_morphodynamique_20261027/working_copies/P06/DYN-Transfert_NonElliptique_Horloge-Gelee_v0_1/draws.csv": "558a88a1249d288110f7467b9c548af56234ec958eeecab38bbaa3a46aed42cc",
    "_audit_codex_pi_morphodynamique_20261027/working_copies/P07/DYN-Comparaison_Contraction-Identique_v0_1/targeted_supports.npz": "5efc10d213e334b0a09d8686b4f7aa3f4f6950d6735a96cbba6999165517530e",
    "_audit_codex_pi_morphodynamique_20261027/working_copies/P08/DYN-Extension_Contraction-Identique_R512_v0_1/extension_supports.npz": "36de3f31f8fdd3c2f02e680a18433f272623c9abfbbf6aeac8452307d69e3ea4",
    "_audit_codex_pi_morphodynamique_20261027/working_copies/P06/DYN-Transfert_NonElliptique_Horloge-Gelee_v0_1/support_shape_engine.py": "f1769af06d914f5ff078a3c22c5c259b8777656d5c3596321362766a6e51a191",
    "_audit_codex_pi_morphodynamique_20261027/working_copies/P07/DYN-Comparaison_Contraction-Identique_v0_1/baseline/polygon_fourier.py": "ec5bcec9b6e5c52bc136f39ee9c27a82a2fbc7c03b2493b24de321c3b4446245",
}

ADDITIONAL = [
    "DYN-Comparaison_Contraction-Identique_v0_1/baseline/support_shape_engine.py",
    "DYN-Comparaison_Contraction-Identique_v0_1/baseline/polygon_fourier.py",
    "DYN-Comparaison_Contraction-Identique_v0_1/run_contraction.py",
    "DYN-Extension_Contraction-Identique_R512_v0_1/run_extension.py",
    "DYN-Comparaison_Contraction-Identique_v0_1/targeted_samples.csv",
    "DYN-Extension_Contraction-Identique_R512_v0_1/extension_samples.csv",
]


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def file_record(relative: str, expected: str | None = None) -> dict:
    path = WORKSPACE / relative
    if not path.is_file():
        return {"path": relative, "status": "MISSING", "expected_sha256": expected}
    observed = sha256(path)
    status = "PRESENT_MATCH" if expected is None or observed == expected else "HASH_MISMATCH"
    return {
        "path": relative,
        "status": status,
        "bytes": path.stat().st_size,
        "sha256": observed,
        "expected_sha256": expected,
    }


def verify_bundle() -> dict:
    archive = WORKSPACE / "DYN-Bilan_et_Controles_Corrections_Finies_v0_4.zip"
    result = {"path": archive.name, "crc": "NOT_CHECKED", "manifest": "NOT_CHECKED"}
    if not archive.is_file():
        result.update(crc="MISSING", manifest="MISSING")
        return result
    with zipfile.ZipFile(archive) as bundle:
        bad_member = bundle.testzip()
        result["crc"] = "OK" if bad_member is None else f"FAIL:{bad_member}"
        names = set(bundle.namelist())
        manifest = json.loads(bundle.read("MANIFEST_SHA256.json"))
        checks = []
        for item in manifest["files"]:
            name = item["path"]
            if name not in names:
                checks.append({"path": name, "present": False, "matches": False})
                continue
            data = bundle.read(name)
            checks.append(
                {
                    "path": name,
                    "present": True,
                    "bytes": len(data),
                    "sha256": sha256_bytes(data),
                    "matches": len(data) == item["bytes"] and sha256_bytes(data) == item["sha256"],
                }
            )
        result.update(
            manifest="OK" if all(item["matches"] for item in checks) else "FAIL",
            declared_files=len(checks),
            checks=checks,
        )
    return result


def main() -> None:
    records = [file_record(path, digest) for path, digest in EXPECTED.items()]
    records.extend(file_record(path) for path in ADDITIONAL)
    bundle = verify_bundle()
    ok = all(item["status"] == "PRESENT_MATCH" for item in records) and bundle["crc"] == "OK" and bundle["manifest"] == "OK"
    payload = {
        "schema_version": "inputs_replication_preparation_v0.4",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "policy": "read and hash only; source archives remain unchanged",
        "inputs": records,
        "bilan_v04_bundle": bundle,
        "summary": {
            "targets": len(records),
            "matching": sum(item["status"] == "PRESENT_MATCH" for item in records),
            "status": "INPUTS_VERIFIED" if ok else "INPUTS_NOT_VERIFIED",
            "new_translation_draw_executed": False,
        },
    }
    OUTPUT.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(payload["summary"], indent=2, ensure_ascii=False))
    if not ok:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
