"""Bounded final validation for the v0.4 preparation delivery.

This script never calls DRAW, RUN, or ANALYZE and never imports a random
number generator.  It verifies provenance, frozen-state integrity, pilot
results, budget arithmetic, and the absence of future campaign artifacts.
"""

from __future__ import annotations

import hashlib
import json
import math
import platform
from importlib import metadata
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parent
OUTPUT = ROOT / "report" / "VALIDATION_FINALE_v0_4.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def main() -> None:
    input_manifest = read_json(ROOT / "input_manifest_v04.json")
    protocol = read_json(ROOT / "protocol_prepare_v04.json")
    plan = read_json(ROOT / "plan" / "PLAN_REPLICATION_INDEPENDANTE_v0_2.json")
    qualification_path = ROOT / "pilot" / "reference_qualification_v04.json"
    qualification = read_json(qualification_path)
    pilot_path = ROOT / "pilot" / "historical_cost_pilot_v04.json"
    pilot = read_json(pilot_path)
    budget_path = ROOT / "pilot" / "cost_budget_v04.json"
    budget = read_json(budget_path)
    state = read_json(ROOT / "launcher_state_v04.json")
    frozen_path = ROOT / "frozen_manifest_v04.json"
    frozen = read_json(frozen_path)

    require(input_manifest["summary"] == {
        "targets": 21,
        "matching": 21,
        "status": "INPUTS_VERIFIED",
        "new_translation_draw_executed": False,
    }, "input manifest summary mismatch")
    require(input_manifest["bilan_v04_bundle"]["crc"] == "OK", "v0.4 ZIP CRC failed")
    require(input_manifest["bilan_v04_bundle"]["manifest"] == "OK", "v0.4 ZIP manifest failed")

    expected_flags = {
        "historical_cost_pilot_executed": True,
        "historical_peeling_replay_executed": True,
        "new_translation_draw": False,
        "master_seed_created": False,
        "new_scientific_peeling_collection": False,
        "new_scientific_collection": False,
        "confirmatory_analysis": False,
        "publication": False,
        "v03_sources_modified": False,
    }
    require(plan["execution_flags"] == expected_flags, "plan execution flags mismatch")
    require(protocol["campaign"]["new_seed"] is None, "protocol contains a seed")
    require(protocol["campaign"]["new_translation_list"] is None, "protocol contains translations")
    require(protocol["campaign"]["complete_rows"] == 64, "campaign n changed")

    require(qualification["status"] == "QUALIFIED_EMPIRICAL_ORACLE_NOT_INTERVAL_CERTIFIED", "oracle status")
    require(qualification["source_sha256"] == sha256(ROOT / "pilot" / "reference_oracle_v04.py"), "oracle hash")
    require(qualification["config_sha256"] == sha256(ROOT / "protocol_prepare_v04.json"), "oracle config hash")
    require(qualification["domain"]["grid_count"] == 1025, "oracle grid count")
    require(qualification["positivity_all_beta_and_methods"] is True, "rho positivity")
    require(max(qualification["epsilon_ref_qualification_grid_max_final"].values()) <= 3e-9, "epsilon threshold")

    required_pilot_flags = {
        "historical_cost_pilot_executed": True,
        "historical_peeling_replay_executed": True,
        "new_translation_draw_executed": False,
        "new_scientific_collection_executed": False,
        "confirmatory_analysis_executed": False,
    }
    require(all(pilot.get(key) == value for key, value in required_pilot_flags.items()), "pilot flags")
    require(pilot["config_sha256"] == sha256(ROOT / "protocol_prepare_v04.json"), "pilot config hash")
    require(len(pilot["lines"]) == 2, "pilot line count")
    for line in pilot["lines"]:
        require(line["primary_archive_replay"]["status"] == "PASS_ARCHIVE_REPLAY", "archive replay")
        comparison = line["second_engine_comparison"]
        require(comparison["status"] == "PASS_COMPLETE_LAYER_BY_LAYER_SECOND_ENGINE", "second engine")
        require(comparison["cumulative_layer_record_sha256_equal"] is True, "layer digest")
        require(comparison["minimum_exact_adjacent_containment_cross"] >= 0, "nesting")

    max_main_wall = max(line["primary_complete_line"]["wall_seconds"] for line in pilot["lines"])
    max_main_cpu = max(line["primary_complete_line"]["cpu_seconds"] for line in pilot["lines"])
    max_main_storage = max(line["primary_complete_line"]["storage_bytes"] for line in pilot["lines"])
    max_second_wall = max(line["second_complete_line_quickhull"]["wall_seconds"] for line in pilot["lines"])
    max_second_cpu = max(line["second_complete_line_quickhull"]["cpu_seconds"] for line in pilot["lines"])
    max_second_storage = max(line["second_complete_line_quickhull"]["storage_bytes"] for line in pilot["lines"])
    reference_wall = qualification["cost"]["production_primary_seven_beta_wall_seconds_observed_within_qualification"]
    reference_cpu = qualification["cost"]["production_primary_seven_beta_cpu_seconds_observed_within_qualification"]
    reference_storage = budget["unit_costs"]["continuous_reference_production_future"]["storage_bytes_projected_from_1025_node_grid"]
    expected_wall = 64 * max_main_wall + 8 * max_second_wall + reference_wall
    expected_cpu = 64 * max_main_cpu + 8 * max_second_cpu + reference_cpu
    expected_storage = 64 * max_main_storage + 8 * max_second_storage + reference_storage
    require(math.isclose(expected_wall, budget["future_campaign_base"]["wall_seconds_sequential"], rel_tol=0, abs_tol=1e-12), "wall budget")
    require(math.isclose(expected_cpu, budget["future_campaign_base"]["cpu_seconds_sequential"], rel_tol=0, abs_tol=1e-12), "CPU budget")
    require(expected_storage == budget["future_campaign_base"]["storage_bytes"], "storage budget")

    require(state["last_completed_action"] == "FREEZE" and state["next_action"] == "DRAW", "launcher state")
    frozen_sha = sha256(frozen_path)
    require(state["frozen_manifest_sha256"] == frozen_sha, "frozen manifest state hash")
    require(frozen["status"] == "FROZEN_BEFORE_DRAW", "frozen status")
    require(frozen["master_seed"] is None and frozen["translation_list"] is None, "future randomization exists")
    require(not frozen["new_draw_executed"] and not frozen["new_campaign_executed"], "future execution flag")
    require(not frozen["confirmatory_analysis_executed"], "confirmatory analysis flag")
    for record in frozen["frozen_files"]:
        path = WORKSPACE / record["path"]
        require(path.is_file(), f"missing frozen file: {record['path']}")
        require(path.stat().st_size == record["bytes"], f"frozen size mismatch: {record['path']}")
        require(sha256(path) == record["sha256"], f"frozen hash mismatch: {record['path']}")

    forbidden = [
        ROOT / "master_seed_v04.txt",
        ROOT / "translations_v04.json",
        ROOT / "campaign_v04",
        ROOT / "analysis_v04",
    ]
    require(not any(path.exists() for path in forbidden), "forbidden future artifact exists")

    current_environment = {
        "python": platform.python_version(),
        "numpy": metadata.version("numpy"),
        "scipy": metadata.version("scipy"),
        "mpmath": metadata.version("mpmath"),
        "threadpoolctl": metadata.version("threadpoolctl"),
        "psutil": metadata.version("psutil"),
    }
    frozen_environment = {
        "python": frozen["environment"]["python"],
        **frozen["environment"]["packages"],
    }
    require(current_environment == frozen_environment, "runtime changed after freeze")

    report_path = ROOT / "report" / "RAPPORT_CLOTURE_ET_PREPARATION_REPLICATION_v0_4.md"
    require(report_path.is_file(), "report missing")
    report_text = report_path.read_text(encoding="utf-8")
    for marker in ("LU, EXÉCUTÉ, INFÉRÉ, NON_DISPONIBLE", "Aucune graine ni liste", "aucun PASS global"):
        require(marker in report_text, f"report marker missing: {marker}")

    result = {
        "status": "DELIVERY_INTERNALLY_CONSISTENT_PREPARATION_ONLY",
        "no_global_pass": True,
        "input_targets_verified": 21,
        "oracle_grid_nodes": 1025,
        "historical_lines_replayed": 2,
        "new_translation_draw_executed": False,
        "new_translation_list_created": False,
        "new_scientific_collection_executed": False,
        "confirmatory_analysis_executed": False,
        "frozen_manifest_sha256": frozen_sha,
        "hashes": {
            "protocol": sha256(ROOT / "protocol_prepare_v04.json"),
            "qualification": sha256(qualification_path),
            "historical_pilot": sha256(pilot_path),
            "budget": sha256(budget_path),
            "launcher": sha256(ROOT / "launcher" / "replication_launcher_v04.py"),
            "analysis": sha256(ROOT / "analysis" / "analyze_replication_v04.py"),
            "report": sha256(report_path),
        },
        "budget_recomputed": {
            "future_wall_seconds": expected_wall,
            "future_cpu_seconds": expected_cpu,
            "future_storage_bytes": expected_storage,
        },
        "runtime": current_environment,
        "remaining_external_decision": "human budget acceptance before providing one post-freeze seed and authorizing DRAW",
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({key: result[key] for key in (
        "status", "input_targets_verified", "oracle_grid_nodes",
        "historical_lines_replayed", "new_translation_draw_executed",
        "confirmatory_analysis_executed", "frozen_manifest_sha256",
    )}, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
