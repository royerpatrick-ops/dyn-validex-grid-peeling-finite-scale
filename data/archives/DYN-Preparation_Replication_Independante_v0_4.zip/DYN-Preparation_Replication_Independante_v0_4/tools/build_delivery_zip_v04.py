"""Create a deterministic delivery ZIP, excluding extracted source copies."""

from __future__ import annotations

import hashlib
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parent
DESTINATION = WORKSPACE / "DYN-Preparation_Replication_Independante_v0_4.zip"
CHECKSUM = WORKSPACE / "DYN-Preparation_Replication_Independante_v0_4.sha256.txt"
ARCHIVE_ROOT = "DYN-Preparation_Replication_Independante_v0_4"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    if DESTINATION.exists() or CHECKSUM.exists():
        raise FileExistsError("refusing to overwrite an existing delivery bundle")
    files = []
    for path in sorted(ROOT.rglob("*"), key=lambda item: item.as_posix().lower()):
        if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        relative = path.relative_to(ROOT).as_posix()
        if relative.startswith("source_review/"):
            continue
        files.append((path, relative))
    with zipfile.ZipFile(DESTINATION, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path, relative in files:
            info = zipfile.ZipInfo(f"{ARCHIVE_ROOT}/{relative}", date_time=(2026, 10, 27, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    digest = sha256(DESTINATION)
    CHECKSUM.write_text(f"{digest}  {DESTINATION.name}\n", encoding="ascii")
    print(f"{DESTINATION.name}\t{DESTINATION.stat().st_size}\t{digest}")


if __name__ == "__main__":
    main()
