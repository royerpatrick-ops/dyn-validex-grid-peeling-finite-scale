"""Hash final derived deliverables for the bounded v0.4 preparation pass."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "report" / "MANIFESTE_SORTIES_SHA256_v0_4.json"
EXCLUDED_PREFIXES = ("source_review/",)
EXCLUDED_NAMES = {"report/MANIFESTE_SORTIES_SHA256_v0_4.json"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    files = []
    for path in sorted(ROOT.rglob("*"), key=lambda item: item.as_posix().lower()):
        if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        relative = path.relative_to(ROOT).as_posix()
        if relative in EXCLUDED_NAMES or any(relative.startswith(prefix) for prefix in EXCLUDED_PREFIXES):
            continue
        files.append({"path": relative, "bytes": path.stat().st_size, "sha256": sha256(path)})
    payload = {
        "schema_version": "replication_preparation_outputs_v0.4",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "root": ROOT.name,
        "policy": "derived delivery files only; extracted source copies and PDF render intermediates excluded",
        "files": files,
        "summary": {
            "file_count": len(files),
            "total_bytes": sum(item["bytes"] for item in files),
            "historical_cost_pilot_executed": True,
            "historical_peeling_replay_executed": True,
            "frozen_before_draw": True,
            "new_translation_draw_executed": False,
            "new_translation_list_created": False,
            "new_scientific_collection_executed": False,
            "confirmatory_analysis_executed": False,
            "publication_executed": False,
        },
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(payload["summary"], indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
